package app.neonvpn;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Subscription download + header parsing (traffic, expiry, title, support links, announcements). Pure Java. */
public final class Subs {
    private Subs() { }

    public static final String DEFAULT_UA = "v2rayNG/1.10.31";

    static String decodeTitle(String v) {
        if (v == null) return "";
        v = v.trim();
        if (v.toLowerCase(Locale.ROOT).startsWith("base64:")) { String d = Links.b64(v.substring(7).trim()); return d == null ? "" : d.trim(); }
        if (v.contains("%")) try { return URLDecoder.decode(v, "UTF-8").trim(); } catch (Exception ignored) { }
        return v;
    }

    static String safeLink(String v) {
        if (v == null) return "";
        v = v.trim();
        String l = v.toLowerCase(Locale.ROOT);
        return (l.startsWith("https://") || l.startsWith("http://") || l.startsWith("tg://")) && v.length() < 2048 ? v : "";
    }

    /** subscription-userinfo: upload=..; download=..; total=..; expire=.. (+ title, links, announce) */
    public static JSONObject info(Net.Resp r) throws Exception {
        JSONObject o = new JSONObject();
        String ui = r.header("subscription-userinfo");
        for (String part : ui.split(";")) {
            int e = part.indexOf('=');
            if (e <= 0) continue;
            String k = part.substring(0, e).trim().toLowerCase(Locale.ROOT);
            long v;
            try { v = (long) Double.parseDouble(part.substring(e + 1).trim()); } catch (Exception ex) { continue; }
            if (k.equals("expire") && v > 100_000_000_000L) v /= 1000;
            if (k.equals("upload") || k.equals("download") || k.equals("total") || k.equals("expire")) o.put(k, Math.max(0, v));
        }
        String title = decodeTitle(r.header("profile-title"));
        if (!title.isEmpty()) o.put("title", title.length() > 100 ? title.substring(0, 100) : title);
        String sup = safeLink(r.header("support-url"));
        if (!sup.isEmpty()) o.put("support", sup);
        String web = safeLink(r.header("profile-web-page-url"));
        if (!web.isEmpty()) o.put("web", web);
        String ann = decodeTitle(r.header("announce"));
        if (!ann.isEmpty()) o.put("announce", ann.length() > 500 ? ann.substring(0, 500) : ann);
        String iv = r.header("profile-update-interval").trim();
        try { if (!iv.isEmpty()) o.put("interval", Math.max(1, Integer.parseInt(iv))); } catch (Exception ignored) { }
        return o;
    }

    public static Map<String, String> headers(String ua, String hwid, String os, String model) {
        Map<String, String> h = new LinkedHashMap<>();
        h.put("User-Agent", ua == null || ua.trim().isEmpty() ? DEFAULT_UA : ua.trim());
        if (hwid != null && !hwid.isEmpty()) {
            h.put("x-hwid", hwid);
            h.put("x-device-os", "Android");
            if (os != null) h.put("x-ver-os", os);
            if (model != null) h.put("x-device-model", model);
        }
        return h;
    }

    public static final class Fetched {
        public final Links.Result parsed;
        public final JSONObject info;
        Fetched(Links.Result p, JSONObject i) { parsed = p; info = i; }
    }

    /** download and parse; tries direct first, then through the tunnel when it is up */
    public static Fetched fetch(String url, Map<String, String> hdr, XrayConfig.Socks viaVpn) throws Exception {
        Net.Resp r = null;
        Exception first = null;
        try { r = Net.get(url, hdr, 20000, null, 8 * 1024 * 1024); } catch (Exception e) { first = e; }
        if ((r == null || r.code != 200) && viaVpn != null) {
            try { r = Net.get(url, hdr, 25000, viaVpn, 8 * 1024 * 1024); } catch (Exception e) { if (first == null) first = e; }
        }
        if (r == null) throw new Exception("не удалось скачать подписку: " + (first == null ? "нет ответа" : first.getMessage()));
        if (r.code == 404) throw new Exception("подписка не найдена (404) — проверьте ссылку");
        if (r.code == 401 || r.code == 403) throw new Exception("сервер подписки отказал в доступе (" + r.code + "). Возможно, превышен лимит устройств или подписка отключена");
        if (r.code != 200) throw new Exception("сервер подписки ответил кодом " + r.code);
        String body = r.text();
        Links.Result p = Links.parseText(body);
        if (p.items.isEmpty()) {
            String t = body.trim().toLowerCase(Locale.ROOT);
            if (t.startsWith("<!doctype") || t.startsWith("<html")) throw new Exception("по ссылке открывается веб-страница, а не подписка. Скопируйте именно ссылку подписки");
            throw new Exception(p.errors.isEmpty() ? "в подписке нет серверов" : p.errors.get(0));
        }
        return new Fetched(p, info(r));
    }

    /** "happ://add/https://..", "v2rayng://install-sub?url=..", "hiddify://import/..#name" -> {url, name} */
    public static JSONObject deepLink(String s) throws Exception {
        String l = s.toLowerCase(Locale.ROOT);
        String url = null, name = "";
        int q = s.indexOf("url=");
        if (q >= 0) {
            String v = s.substring(q + 4);
            int amp = v.indexOf('&');
            if (amp >= 0) {
                String rest = v.substring(amp + 1);
                v = v.substring(0, amp);
                int n = rest.indexOf("name=");
                if (n >= 0) name = Links.pdec(rest.substring(n + 5).split("&")[0]);
            }
            url = Links.pdec(v);
        } else {
            for (String pre : new String[]{"happ://add/", "neonvpn://add/", "neonvpn://import/", "hiddify://import/", "streisand://import/", "v2raytun://import/", "karing://install-config/"}) {
                if (l.startsWith(pre)) { url = s.substring(pre.length()); break; }
            }
            if (url != null) {
                int h = url.indexOf('#');
                if (h >= 0) { name = Links.pdec(url.substring(h + 1)); url = url.substring(0, h); }
                if (url.contains("%3A%2F%2F") || url.contains("%3a%2f%2f")) url = Links.pdec(url);
            }
        }
        if (l.startsWith("happ://crypt")) throw new Exception("зашифрованные ссылки Happ открываются только в Happ — попросите обычную ссылку подписки");
        if (url == null || !(url.toLowerCase(Locale.ROOT).startsWith("http") || Links.isLink(url))) return null;
        return new JSONObject().put("url", url).put("name", name);
    }

    public static JSONArray names(Links.Result r) {
        JSONArray a = new JSONArray();
        for (JSONObject o : r.items) a.put(o.optString("name"));
        return a;
    }
}
