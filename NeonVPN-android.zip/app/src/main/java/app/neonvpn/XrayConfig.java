package app.neonvpn;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Builds Xray-core JSON configs from profiles and app settings. Pure Java. */
public final class XrayConfig {
    private XrayConfig() { }

    public static final int LEVEL = 8;
    static final Set<String> FINGERPRINTS = new HashSet<>(Arrays.asList("chrome", "firefox", "safari", "ios", "android", "edge", "360", "qq", "random", "randomized", "randomizednoalpn"));

    /** local SOCKS inbound used only by the app itself (IP check, updates through the tunnel) */
    public static final class Socks {
        public final int port; public final String user, pass;
        public Socks(int port, String user, String pass) { this.port = port; this.user = user; this.pass = pass; }
    }

    static boolean isIp(String h) {
        return h.matches("\\d{1,3}(\\.\\d{1,3}){3}") || h.contains(":");
    }

    static boolean isDomain(String h) { return h != null && !h.isEmpty() && !isIp(h) && h.contains("."); }

    static JSONArray arr(String... v) { JSONArray a = new JSONArray(); for (String s : v) a.put(s); return a; }

    static JSONArray csv(String s) {
        JSONArray a = new JSONArray();
        if (s == null) return a;
        for (String x : s.split(",")) { x = x.trim(); if (!x.isEmpty()) a.put(x); }
        return a;
    }

    static void opt(JSONObject o, String k, String v) throws Exception { if (v != null && !v.isEmpty()) o.put(k, v); }

    /* ======================= outbound for one profile ======================= */
    /**
     * @param pin SHA-256 of the server certificate for "allowInsecure" links (Xray removed allowInsecure)
     */
    public static JSONObject outbound(JSONObject p, String tag, JSONObject s, String pin) throws Exception {
        String proto = p.optString("proto");
        JSONObject ob = new JSONObject();
        ob.put("tag", tag);
        JSONObject st = new JSONObject();
        String addr = p.optString("addr");
        int port = p.optInt("port");
        if (addr.isEmpty() || port <= 0) throw new Exception("у сервера нет адреса или порта");
        st.put("address", addr);
        st.put("port", port);
        st.put("level", LEVEL);
        boolean stream = true;
        switch (proto) {
            case "vless":
                ob.put("protocol", "vless");
                st.put("id", p.optString("uuid"));
                st.put("encryption", p.optString("enc").isEmpty() ? "none" : p.optString("enc"));
                opt(st, "flow", p.optString("flow"));
                break;
            case "vmess":
                ob.put("protocol", "vmess");
                st.put("id", p.optString("uuid"));
                st.put("security", p.optString("method").isEmpty() ? "auto" : p.optString("method"));
                break;
            case "trojan":
                ob.put("protocol", "trojan");
                st.put("password", p.optString("pass"));
                break;
            case "ss":
                ob.put("protocol", "shadowsocks");
                st.put("method", p.optString("method"));
                st.put("password", p.optString("pass"));
                break;
            case "socks": case "http":
                ob.put("protocol", proto);
                if (!p.optString("user").isEmpty()) { st.put("user", p.optString("user")); st.put("pass", p.optString("pass")); }
                stream = false;
                break;
            case "hy2":
                ob.put("protocol", "hysteria");
                st.remove("level");
                st.put("version", 2);
                break;
            default:
                throw new Exception("неизвестный протокол: " + proto);
        }
        ob.put("settings", st);
        if (stream) ob.put("streamSettings", stream(p, s, pin));
        if (s != null && s.optBoolean("mux") && (proto.equals("vmess") || (proto.equals("vless") && p.optString("flow").isEmpty()))
                && !"xhttp".equals(normNet(p.optString("net")))) {
            JSONObject mux = new JSONObject();
            mux.put("enabled", true);
            mux.put("concurrency", 8);
            mux.put("xudpConcurrency", 16);
            mux.put("xudpProxyUDP443", "reject");
            ob.put("mux", mux);
        }
        return ob;
    }

    static String normNet(String n) {
        n = n == null ? "" : n.toLowerCase(Locale.ROOT);
        switch (n) {
            case "": case "raw": case "tcp": return "tcp";
            case "splithttp": case "xhttp": return "xhttp";
            case "websocket": case "ws": return "ws";
            case "mkcp": case "kcp": return "kcp";
            default: return n;
        }
    }

    static JSONObject stream(JSONObject p, JSONObject s, String pin) throws Exception {
        JSONObject ss = new JSONObject();
        String net = "hy2".equals(p.optString("proto")) ? "hysteria" : normNet(p.optString("net"));
        String host = p.optString("host"), path = p.optString("path");
        String sniExt = null;
        switch (net) {
            case "tcp": {
                JSONObject tcp = new JSONObject(), header = new JSONObject();
                if ("http".equals(p.optString("htype"))) {
                    header.put("type", "http");
                    JSONObject req = new JSONObject();
                    req.put("version", "1.1");
                    req.put("method", "GET");
                    JSONArray paths = csv(path);
                    req.put("path", paths.length() == 0 ? arr("/") : paths);
                    JSONObject hd = new JSONObject();
                    JSONArray hosts = csv(host);
                    if (hosts.length() > 0) { hd.put("Host", hosts); sniExt = hosts.optString(0); }
                    hd.put("User-Agent", arr("Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.122 Mobile Safari/537.36"));
                    hd.put("Accept-Encoding", arr("gzip, deflate"));
                    hd.put("Connection", arr("keep-alive"));
                    hd.put("Pragma", "no-cache");
                    req.put("headers", hd);
                    header.put("request", req);
                } else { header.put("type", "none"); sniExt = host; }
                tcp.put("header", header);
                ss.put("tcpSettings", tcp);
                break;
            }
            case "ws": case "httpupgrade": {
                JSONObject w = new JSONObject();
                w.put("host", host);
                w.put("path", path.isEmpty() ? "/" : path);
                ss.put(net.equals("ws") ? "wsSettings" : "httpupgradeSettings", w);
                sniExt = host;
                break;
            }
            case "xhttp": {
                JSONObject x = new JSONObject();
                x.put("host", host);
                x.put("path", path.isEmpty() ? "/" : path);
                opt(x, "mode", p.optString("mode"));
                String extra = p.optString("extra");
                if (!extra.isEmpty()) try { x.put("extra", new JSONObject(extra)); } catch (Exception ignored) { }
                ss.put("xhttpSettings", x);
                sniExt = host;
                break;
            }
            case "grpc": {
                JSONObject g = new JSONObject();
                g.put("serviceName", p.optString("svc"));
                g.put("authority", p.optString("auth"));
                g.put("multiMode", "multi".equals(p.optString("mode")));
                g.put("idle_timeout", 60);
                g.put("health_check_timeout", 20);
                ss.put("grpcSettings", g);
                sniExt = p.optString("auth");
                break;
            }
            case "kcp": {
                JSONObject k = new JSONObject();
                k.put("mtu", 1350); k.put("tti", 50); k.put("uplinkCapacity", 12); k.put("downlinkCapacity", 100);
                k.put("congestion", false); k.put("readBufferSize", 1); k.put("writeBufferSize", 1);
                ss.put("kcpSettings", k);
                JSONArray udp = new JSONArray();
                String seed = p.optString("seed"), ht = p.optString("htype");
                JSONObject m1 = new JSONObject().put("type", "mkcp-legacy");
                if (!seed.isEmpty()) m1.put("settings", new JSONObject().put("value", seed));
                udp.put(m1);
                if (!ht.isEmpty() && !ht.equals("none")) {
                    JSONObject hs = new JSONObject().put("header", ht.equals("wechat-video") ? "wechat" : ht);
                    if (ht.equals("dns") && !host.isEmpty()) hs.put("value", host);
                    udp.put(new JSONObject().put("type", "mkcp-legacy").put("settings", hs));
                }
                ss.put("finalmask", new JSONObject().put("udp", udp));
                break;
            }
            case "hysteria": {
                ss.put("hysteriaSettings", new JSONObject().put("version", 2).put("auth", p.optString("pass")));
                if (!p.optString("obfs").isEmpty())
                    ss.put("finalmask", new JSONObject().put("udp", new JSONArray().put(new JSONObject().put("type", "salamander").put("settings", new JSONObject().put("password", p.optString("obfs"))))));
                break;
            }
            case "h2": case "http": case "h3":
                throw new Exception("транспорт HTTP/2 удалён из ядра Xray — попросите у провайдера ссылку с XHTTP");
            case "quic":
                throw new Exception("транспорт QUIC удалён из ядра Xray");
            default:
                throw new Exception("неизвестный транспорт: " + net);
        }
        ss.put("network", net);
        String sec = p.optString("sec");
        if ("hy2".equals(p.optString("proto"))) sec = "tls";
        if (sec.equals("tls") || sec.equals("reality")) {
            ss.put("security", sec);
            String addr = p.optString("addr");
            String sni = p.optString("sni");
            if (sni.isEmpty()) sni = isDomain(sniExt) ? sniExt : isDomain(addr) ? addr : (sniExt == null ? "" : sniExt);
            String fp = p.optString("fp").toLowerCase(Locale.ROOT);
            if (!fp.isEmpty() && !FINGERPRINTS.contains(fp)) fp = "chrome";
            JSONObject t = new JSONObject();
            opt(t, "serverName", sni);
            if (sec.equals("tls")) {
                opt(t, "fingerprint", fp);
                JSONArray alpn = "hy2".equals(p.optString("proto")) ? arr("h3") : csv(p.optString("alpn"));
                if (alpn.length() > 0) t.put("alpn", alpn);
                opt(t, "echConfigList", p.optString("ech"));
                opt(t, "verifyPeerCertByName", p.optString("vcn"));
                String pcs = p.optString("pcs");
                if (pcs.isEmpty() && pin != null) pcs = pin;
                opt(t, "pinnedPeerCertSha256", pcs);
                ss.put("tlsSettings", t);
            } else {
                t.put("fingerprint", fp.isEmpty() ? "chrome" : fp);
                t.put("publicKey", p.optString("pbk"));
                opt(t, "shortId", p.optString("sid"));
                opt(t, "spiderX", p.optString("spx"));
                opt(t, "mldsa65Verify", p.optString("pqv"));
                ss.put("realitySettings", t);
            }
            String fm = p.optString("fm");
            if (!fm.isEmpty()) {
                try { ss.put("finalmask", new JSONObject(fm)); } catch (Exception ignored) { }
            } else if (s != null && s.optBoolean("fragment") && !net.equals("hysteria") && !net.equals("kcp")) {
                JSONObject fs = new JSONObject();
                fs.put("packets", sec.equals("reality") ? "1-3" : "tlshello");
                fs.put("length", s.optString("fragLen", "50-100"));
                fs.put("delay", s.optString("fragDelay", "10-20"));
                fs.put("maxSplit", "10");
                ss.put("finalmask", new JSONObject().put("tcp", new JSONArray().put(new JSONObject().put("type", "fragment").put("settings", fs))));
            }
        }
        return ss;
    }

    /* ======================= full configs ======================= */
    static JSONObject rule(String outbound) throws Exception {
        JSONObject r = new JSONObject();
        r.put("type", "field");
        r.put("outboundTag", outbound);
        return r;
    }

    /** split user rule values into Xray domain and ip lists */
    static void addUserRules(JSONArray rules, JSONArray user, String action, String proxyTag, boolean balancer) throws Exception {
        if (user == null) return;
        JSONArray dom = new JSONArray(), ip = new JSONArray();
        for (int i = 0; i < user.length(); i++) {
            JSONObject u = user.optJSONObject(i);
            if (u == null || !action.equals(u.optString("act"))) continue;
            for (String v : u.optString("v").split("[,\\s]+")) {
                v = v.trim();
                if (v.isEmpty()) continue;
                String lv = v.toLowerCase(Locale.ROOT);
                boolean isIp = lv.startsWith("geoip:") || lv.matches("\\d{1,3}(\\.\\d{1,3}){3}(/\\d{1,2})?") || (lv.contains(":") && lv.matches("[0-9a-f:]+(/\\d{1,3})?"));
                if (isIp) ip.put(lv);
                else if (lv.startsWith("geosite:") || lv.startsWith("domain:") || lv.startsWith("full:") || lv.startsWith("regexp:") || lv.startsWith("keyword:")) dom.put(v);
                else {
                    String d = lv.replaceFirst("^https?://", "").replaceFirst("/.*$", "").replaceFirst("^\\*\\.", "");
                    if (!d.isEmpty()) dom.put("domain:" + d);
                }
            }
        }
        for (JSONArray list : new JSONArray[]{dom, ip}) {
            if (list.length() == 0) continue;
            JSONObject r = new JSONObject();
            r.put("type", "field");
            r.put(list == dom ? "domain" : "ip", list);
            target(r, action.equals("proxy") ? proxyTag : action, balancer && action.equals("proxy"));
            rules.put(r);
        }
    }

    static void target(JSONObject r, String tag, boolean balancer) throws Exception {
        if (balancer) r.put("balancerTag", tag); else r.put("outboundTag", tag);
    }

    /** routing rules shared by normal and auto-select configs */
    static JSONArray rules(JSONObject s, boolean hasSocks, String proxyTag, boolean balancer) throws Exception {
        JSONArray rules = new JSONArray();
        if (hasSocks) { JSONObject r = new JSONObject().put("type", "field").put("inboundTag", arr("socks-in")); target(r, proxyTag, balancer); rules.put(r); }
        if (s.optBoolean("bypassLan", true)) {
            rules.put(rule("direct").put("ip", arr("geoip:private")));
            rules.put(rule("direct").put("domain", arr("geosite:private")));
        }
        JSONArray user = s.optJSONArray("rules");
        addUserRules(rules, user, "block", proxyTag, balancer);
        addUserRules(rules, user, "direct", proxyTag, balancer);
        addUserRules(rules, user, "proxy", proxyTag, balancer);
        if (s.optBoolean("blockAds")) rules.put(rule("block").put("domain", arr("geosite:category-ads-all")));
        rules.put(rule("direct").put("protocol", arr("bittorrent")));
        if (s.optBoolean("blockQuic", true)) rules.put(rule("block").put("network", "udp").put("port", "443"));
        if (!s.optBoolean("ipv6")) rules.put(rule("block").put("ip", arr("::/0")));
        if ("ru".equals(s.optString("route", "ru"))) {
            rules.put(rule("direct").put("domain", arr("geosite:category-ru", "domain:ru", "domain:su", "domain:xn--p1ai")));
            rules.put(rule("direct").put("ip", arr("geoip:ru")));
        }
        JSONObject last = new JSONObject().put("type", "field").put("network", "tcp,udp");
        target(last, proxyTag, balancer);
        rules.put(last);
        return rules;
    }

    static JSONObject tunInbound(JSONObject s) throws Exception {
        JSONObject in = new JSONObject();
        in.put("tag", "tun");
        in.put("protocol", "tun");
        in.put("settings", new JSONObject().put("name", "xray0").put("mtu", s.optInt("mtu", 1500)).put("userLevel", LEVEL));
        in.put("sniffing", sniffing(s));
        return in;
    }

    static JSONObject sniffing(JSONObject s) throws Exception {
        return new JSONObject().put("enabled", s.optBoolean("sniff", true)).put("destOverride", arr("http", "tls", "quic")).put("routeOnly", true);
    }

    static JSONObject socksInbound(Socks k, JSONObject s) throws Exception {
        JSONObject in = new JSONObject();
        in.put("tag", "socks-in");
        in.put("listen", "127.0.0.1");
        in.put("port", k.port);
        in.put("protocol", "socks");
        in.put("settings", new JSONObject().put("auth", "password").put("accounts", new JSONArray().put(new JSONObject().put("user", k.user).put("pass", k.pass))).put("udp", false).put("userLevel", LEVEL));
        in.put("sniffing", sniffing(s));
        return in;
    }

    static void common(JSONObject c, JSONObject s) throws Exception {
        c.put("log", new JSONObject().put("loglevel", s.optString("logLevel", "warning")));
        c.put("stats", new JSONObject());
        c.put("policy", new JSONObject()
                .put("levels", new JSONObject().put(String.valueOf(LEVEL), new JSONObject().put("handshake", 4).put("connIdle", 300).put("uplinkOnly", 1).put("downlinkOnly", 1)))
                .put("system", new JSONObject().put("statsOutboundUplink", true).put("statsOutboundDownlink", true)));
    }

    static JSONArray tailOutbounds(JSONArray obs) throws Exception {
        obs.put(new JSONObject().put("tag", "direct").put("protocol", "freedom"));
        obs.put(new JSONObject().put("tag", "block").put("protocol", "blackhole").put("settings", new JSONObject().put("response", new JSONObject().put("type", "http"))));
        return obs;
    }

    /**
     * Running config. One profile = "proxy" outbound; several = auto mode with a leastPing balancer
     * that keeps probing the servers and switches when the current one dies.
     */
    public static JSONObject build(List<JSONObject> profiles, JSONObject s, boolean tun, Socks socks, Map<String, String> pins) throws Exception {
        if (profiles.isEmpty()) throw new Exception("не выбран сервер");
        if (profiles.size() == 1 && "custom".equals(profiles.get(0).optString("proto"))) return custom(profiles.get(0), s, tun, socks);
        JSONObject c = new JSONObject();
        common(c, s);
        JSONArray ins = new JSONArray();
        if (tun) ins.put(tunInbound(s));
        if (socks != null) ins.put(socksInbound(socks, s));
        c.put("inbounds", ins);
        JSONArray obs = new JSONArray();
        boolean auto = profiles.size() > 1;
        List<String> errors = new ArrayList<>();
        int n = 0;
        for (JSONObject p : profiles) {
            if ("custom".equals(p.optString("proto"))) continue;
            try {
                obs.put(outbound(p, auto ? "proxy-" + n : "proxy", s, pins == null ? null : pins.get(p.optString("id"))));
                n++;
            } catch (Exception e) {
                if (!auto) throw e;
                errors.add(p.optString("name") + ": " + e.getMessage());
            }
        }
        if (n == 0) throw new Exception(errors.isEmpty() ? "нет подходящих серверов" : errors.get(0));
        c.put("outbounds", tailOutbounds(obs));
        JSONObject routing = new JSONObject().put("domainStrategy", "AsIs");
        routing.put("rules", rules(s, socks != null, auto ? "auto" : "proxy", auto));
        if (auto) {
            String url = s.optString("testUrl", "https://www.gstatic.com/generate_204");
            routing.put("balancers", new JSONArray().put(new JSONObject().put("tag", "auto").put("selector", arr("proxy-"))
                    .put("strategy", new JSONObject().put("type", "leastPing")).put("fallbackTag", "proxy-0")));
            c.put("observatory", new JSONObject().put("subjectSelector", arr("proxy-")).put("probeURL", url).put("probeInterval", "1m").put("enableConcurrency", true));
        }
        c.put("routing", routing);
        return c;
    }

    /** full Xray JSON from a subscription: keep its outbounds/routing/dns, replace inbounds with ours */
    static JSONObject custom(JSONObject p, JSONObject s, boolean tun, Socks socks) throws Exception {
        JSONObject c = new JSONObject(p.optString("cfg"));
        c.remove("remarks");
        common(c, s);
        JSONArray ins = new JSONArray();
        if (tun) ins.put(tunInbound(s));
        if (socks != null) ins.put(socksInbound(socks, s));
        c.put("inbounds", ins);
        JSONArray obs = c.optJSONArray("outbounds");
        if (obs == null || obs.length() == 0) throw new Exception("в конфиге нет outbounds");
        Set<String> tags = new HashSet<>();
        for (int i = 0; i < obs.length(); i++) tags.add(obs.optJSONObject(i).optString("tag"));
        if (!tags.contains("direct")) obs.put(new JSONObject().put("tag", "direct").put("protocol", "freedom"));
        if (!tags.contains("block")) obs.put(new JSONObject().put("tag", "block").put("protocol", "blackhole"));
        JSONObject routing = c.optJSONObject("routing");
        if (routing == null) { routing = new JSONObject().put("domainStrategy", "AsIs"); c.put("routing", routing); }
        JSONArray rules = routing.optJSONArray("rules");
        if (rules == null) rules = new JSONArray();
        JSONArray pre = new JSONArray();
        String first = obs.optJSONObject(0).optString("tag");
        if (socks != null && !first.isEmpty() && !first.equals("direct") && !first.equals("block"))
            pre.put(new JSONObject().put("type", "field").put("inboundTag", arr("socks-in")).put("outboundTag", first));
        if (!s.optBoolean("ipv6")) pre.put(rule("block").put("ip", arr("::/0")));
        if (s.optBoolean("blockAds")) pre.put(rule("block").put("domain", arr("geosite:category-ads-all")));
        for (int i = 0; i < rules.length(); i++) pre.put(rules.get(i));
        routing.put("rules", pre);
        return c;
    }

    /** config for Libv2ray.measureOutboundDelay: just the server outbound */
    public static String speedtest(JSONObject p, JSONObject s, String pin) throws Exception {
        if ("custom".equals(p.optString("proto"))) {
            JSONObject c = new JSONObject(p.optString("cfg"));
            c.remove("inbounds");
            c.remove("dns");
            c.remove("routing");
            c.remove("observatory");
            c.remove("burstObservatory");
            c.put("log", new JSONObject().put("loglevel", "none"));
            return c.toString();
        }
        JSONObject c = new JSONObject();
        c.put("log", new JSONObject().put("loglevel", "none"));
        JSONObject ob = outbound(p, "proxy", s, pin);
        ob.remove("mux");
        c.put("outbounds", new JSONArray().put(ob).put(new JSONObject().put("tag", "direct").put("protocol", "freedom")));
        return c.toString();
    }
}
