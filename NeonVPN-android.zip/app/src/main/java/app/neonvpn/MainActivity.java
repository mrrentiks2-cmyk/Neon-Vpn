package app.neonvpn;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity implements VpnCore.Listener {
    static final String HOST = "appassets.androidplatform.net";
    static final String START = "https://" + HOST + "/assets/www/index.html";
    static final int REQ_VPN = 21, REQ_CAM = 22, REQ_NOTIF = 23, REQ_IMG = 24;
    static final int BG = Color.parseColor("#07080d");

    WebView web;
    WebViewAssetLoader loader;
    VpnCore core;
    final Handler ui = new Handler(Looper.getMainLooper());
    String pending;
    PermissionRequest camReq;
    ValueCallback<Uri[]> fileCb;
    final Map<String, byte[]> iconCache = new HashMap<>();

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        core = VpnCore.get(this);
        core.listener = this;
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        web = new WebView(this);
        web.setBackgroundColor(BG);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        loader = new WebViewAssetLoader.Builder().setDomain(HOST).addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                if ("/appicon".equals(u.getPath())) return appIcon(u.getQueryParameter("p"));
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openUrl(u.toString());
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest r) {
                ui.post(() -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) r.grant(r.getResources());
                    else { camReq = r; requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM); }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), REQ_IMG); }
                catch (Exception e) { fileCb = null; cb.onReceiveValue(null); return false; }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "V");
        web.loadUrl(START);
        handleIntent(getIntent());
        core.io.execute(() -> core.autoUpdate(false));
    }

    WebResourceResponse appIcon(String pkg) {
        try {
            byte[] png;
            synchronized (iconCache) { png = iconCache.get(pkg); }
            if (png == null) {
                Drawable d = getPackageManager().getApplicationIcon(pkg);
                int sz = 96;
                Bitmap b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(b);
                d.setBounds(0, 0, sz, sz);
                d.draw(c);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.PNG, 90, bo);
                png = bo.toByteArray();
                synchronized (iconCache) { iconCache.put(pkg, png); }
            }
            WebResourceResponse r = new WebResourceResponse("image/png", null, new ByteArrayInputStream(png));
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "max-age=86400");
            r.setResponseHeaders(h);
            return r;
        } catch (Exception e) {
            WebResourceResponse r = new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            r.setStatusCodeAndReasonPhrase(404, "Not Found");
            return r;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    void handleIntent(Intent i) {
        if (i == null) return;
        if (i.getBooleanExtra("connect", false)) { i.removeExtra("connect"); ui.postDelayed(this::connect, 400); return; }
        String text = null;
        if (Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) text = i.getData().toString();
        else if (Intent.ACTION_SEND.equals(i.getAction())) {
            CharSequence t = i.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (t != null) text = t.toString();
        }
        if (text == null || text.trim().isEmpty()) return;
        synchronized (this) { pending = text.trim(); }
        emit(VpnCore.ev("intent"));
    }

    @Override
    protected void onResume() {
        super.onResume();
        core.listener = this;
        emit(core.stateJson());
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__vBack && window.__vBack()) ? 1 : 0", r -> { if (!"1".equals(r)) moveTaskToBack(true); });
    }

    @Override
    protected void onDestroy() {
        if (core.listener == this) core.listener = null;
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    @Override
    public void emit(JSONObject o) {
        final String js = "window.__vEvent && window.__vEvent(" + JSONObject.quote(o.toString()) + ")";
        ui.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    void toast(String t) { ui.post(() -> Toast.makeText(this, t, Toast.LENGTH_LONG).show()); }

    void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { toast("Не удалось открыть ссылку"); }
    }

    /* ======================= VPN on/off ======================= */
    void connect() {
        Intent prep;
        try { prep = VpnService.prepare(this); } catch (Exception e) { toast("VPN недоступен: " + e.getMessage()); return; }
        if (prep != null) {
            try { startActivityForResult(prep, REQ_VPN); } catch (Exception e) { toast("Не удалось запросить разрешение на VPN"); }
            return;
        }
        askNotifications();
        NeonVpnService.start(this);
    }

    void askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !core.prefs.getBoolean("askedNotif", false)) {
            core.prefs.edit().putBoolean("askedNotif", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_VPN) {
            if (res == RESULT_OK) { askNotifications(); NeonVpnService.start(this); }
            else { core.setState("off", "Нужно разрешить подключение VPN"); }
        } else if (req == REQ_IMG) {
            if (fileCb != null) { fileCb.onReceiveValue(res == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null); fileCb = null; }
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        if (req == REQ_CAM && camReq != null) { if (ok) camReq.grant(camReq.getResources()); else camReq.deny(); camReq = null; }
        try { emit(VpnCore.ev("perm").put("req", req == REQ_CAM ? "camera" : "notify").put("granted", ok)); } catch (Exception ignored) { }
    }

    /* ======================= JS bridge ======================= */
    class Bridge {
        @JavascriptInterface public int sdk() { return Build.VERSION.SDK_INT; }

        @JavascriptInterface
        public void call(String id, String method, String args) {
            core.io.execute(() -> {
                JSONObject e = VpnCore.ev("res");
                try {
                    e.put("id", id);
                    Object r = core.call(method, new JSONObject(args == null || args.isEmpty() ? "{}" : args));
                    e.put("ok", true);
                    e.put("data", r == null ? JSONObject.NULL : r);
                } catch (Throwable t) {
                    try { e.put("ok", false); e.put("error", t.getMessage() == null ? t.toString() : t.getMessage()); } catch (Exception ignored) { }
                }
                emit(e);
            });
        }

        @JavascriptInterface public String state() { return core.stateJson().toString(); }

        @JavascriptInterface public void connect() { ui.post(MainActivity.this::connect); }

        @JavascriptInterface public void disconnect() { ui.post(() -> NeonVpnService.stop(MainActivity.this)); }

        @JavascriptInterface
        public String clip() {
            final String[] out = {""};
            CountDownLatch l = new CountDownLatch(1);
            ui.post(() -> {
                try {
                    ClipboardManager cm = getSystemService(ClipboardManager.class);
                    ClipData d = cm.getPrimaryClip();
                    if (d != null && d.getItemCount() > 0) { CharSequence t = d.getItemAt(0).coerceToText(MainActivity.this); out[0] = t == null ? "" : t.toString(); }
                } catch (Exception ignored) { }
                l.countDown();
            });
            try { l.await(2, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            return out[0];
        }

        @JavascriptInterface
        public void copy(String text) {
            ui.post(() -> {
                try {
                    getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("Neon VPN", text));
                    if (Build.VERSION.SDK_INT < 33) Toast.makeText(MainActivity.this, "Скопировано", Toast.LENGTH_SHORT).show();
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void share(String text) {
            ui.post(() -> {
                try { startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Поделиться")); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface public void openUrl(String u) { ui.post(() -> MainActivity.this.openUrl(u)); }

        @JavascriptInterface public void toast(String t) { MainActivity.this.toast(t); }

        @JavascriptInterface public boolean camAllowed() { return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED; }

        @JavascriptInterface
        public void askCam() { ui.post(() -> requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM)); }

        @JavascriptInterface
        public boolean notifyAllowed() {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
            return getSystemService(NotificationManager.class).areNotificationsEnabled();
        }

        @JavascriptInterface
        public void vpnSettings() {
            ui.post(() -> {
                try { startActivity(new Intent(Settings.ACTION_VPN_SETTINGS)); }
                catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); } catch (Exception ignored) { } }
            });
        }

        @JavascriptInterface
        public String takeIntent() {
            synchronized (MainActivity.this) { String p = pending == null ? "" : pending; pending = null; return p; }
        }

        @JavascriptInterface
        public boolean alwaysOn() {
            try { return Build.VERSION.SDK_INT >= 29 && isAlwaysOnHint(); } catch (Exception e) { return false; }
        }
    }

    boolean isAlwaysOnHint() {
        String v = Settings.Secure.getString(getContentResolver(), "always_on_vpn_app");
        return getPackageName().equals(v);
    }
}
