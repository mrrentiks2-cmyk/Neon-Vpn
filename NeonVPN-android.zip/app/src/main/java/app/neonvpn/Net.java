package app.neonvpn;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/** Small HTTP client: direct, or through the local authenticated SOCKS5 inbound of Xray. Pure Java. */
public final class Net {
    private Net() { }

    public static final class Resp {
        public int code;
        public String url;
        public final Map<String, String> headers = new HashMap<>();
        public byte[] body = new byte[0];
        public String text() { return new String(body, StandardCharsets.UTF_8); }
        public String header(String k) { String v = headers.get(k.toLowerCase(Locale.ROOT)); return v == null ? "" : v; }
    }

    public static Resp get(String url, Map<String, String> hdr, int timeout, XrayConfig.Socks socks, int maxBytes) throws Exception {
        if (socks != null) return viaSocks(url, hdr, timeout, socks, maxBytes, 0);
        Resp r = new Resp();
        String cur = url;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(timeout);
            c.setReadTimeout(timeout);
            c.setRequestProperty("Accept", "*/*");
            c.setRequestProperty("Accept-Encoding", "identity");
            if (hdr != null) for (Map.Entry<String, String> e : hdr.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
            int code = c.getResponseCode();
            if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                cur = new URL(new URL(cur), c.getHeaderField("Location")).toString();
                c.disconnect();
                continue;
            }
            r.code = code;
            r.url = cur;
            for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet())
                if (e.getKey() != null && !e.getValue().isEmpty()) r.headers.put(e.getKey().toLowerCase(Locale.ROOT), e.getValue().get(0));
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            r.body = in == null ? new byte[0] : readAll(in, maxBytes);
            c.disconnect();
            return r;
        }
        throw new IOException("слишком много перенаправлений");
    }

    static byte[] readAll(InputStream in, int max) throws IOException {
        try (InputStream i = in) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = i.read(b)) > 0) { bo.write(b, 0, n); if (bo.size() > max) throw new IOException("ответ слишком большой"); }
            return bo.toByteArray();
        }
    }

    /* ======================= SOCKS5 ======================= */
    static void readFully(InputStream in, byte[] b) throws IOException {
        int off = 0;
        while (off < b.length) { int n = in.read(b, off, b.length - off); if (n < 0) throw new IOException("SOCKS: соединение закрыто"); off += n; }
    }

    /** open a TCP connection to host:port through the local SOCKS5 server with username/password */
    public static Socket socksConnect(XrayConfig.Socks k, String host, int port, int timeout) throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress("127.0.0.1", k.port), timeout);
        s.setSoTimeout(timeout);
        OutputStream out = s.getOutputStream();
        InputStream in = s.getInputStream();
        out.write(new byte[]{5, 1, 2});
        byte[] two = new byte[2];
        readFully(in, two);
        if (two[0] != 5 || two[1] != 2) { s.close(); throw new IOException("SOCKS: метод входа не принят"); }
        byte[] u = k.user.getBytes(StandardCharsets.UTF_8), p = k.pass.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream a = new ByteArrayOutputStream();
        a.write(1); a.write(u.length); a.write(u, 0, u.length); a.write(p.length); a.write(p, 0, p.length);
        out.write(a.toByteArray());
        readFully(in, two);
        if (two[1] != 0) { s.close(); throw new IOException("SOCKS: неверный пароль"); }
        byte[] h = host.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream c = new ByteArrayOutputStream();
        c.write(5); c.write(1); c.write(0); c.write(3); c.write(h.length); c.write(h, 0, h.length); c.write((port >> 8) & 0xff); c.write(port & 0xff);
        out.write(c.toByteArray());
        byte[] head = new byte[4];
        readFully(in, head);
        if (head[1] != 0) { s.close(); throw new IOException("SOCKS: сервер не смог подключиться (код " + head[1] + ")"); }
        int skip = head[3] == 1 ? 4 : head[3] == 4 ? 16 : -1;
        if (skip < 0) { int l = in.read(); skip = l; }
        readFully(in, new byte[skip + 2]);
        return s;
    }

    static Resp viaSocks(String url, Map<String, String> hdr, int timeout, XrayConfig.Socks k, int maxBytes, int hop) throws Exception {
        if (hop > 5) throw new IOException("слишком много перенаправлений");
        URL u = new URL(url);
        boolean tls = u.getProtocol().equalsIgnoreCase("https");
        int port = u.getPort() > 0 ? u.getPort() : tls ? 443 : 80;
        Socket s = socksConnect(k, u.getHost(), port, timeout);
        try {
            if (tls) {
                SSLSocket ssl = (SSLSocket) ((SSLSocketFactory) SSLSocketFactory.getDefault()).createSocket(s, u.getHost(), port, true);
                ssl.startHandshake();
                HostnameVerifier hv = HttpsURLConnection.getDefaultHostnameVerifier();
                if (!hv.verify(u.getHost(), ssl.getSession())) throw new IOException("сертификат не подходит для " + u.getHost());
                s = ssl;
            }
            String path = (u.getPath() == null || u.getPath().isEmpty() ? "/" : u.getPath()) + (u.getQuery() == null ? "" : "?" + u.getQuery());
            StringBuilder req = new StringBuilder();
            req.append("GET ").append(path).append(" HTTP/1.1\r\nHost: ").append(u.getHost()).append(u.getPort() > 0 ? ":" + u.getPort() : "")
                    .append("\r\nAccept: */*\r\nAccept-Encoding: identity\r\nConnection: close\r\n");
            if (hdr != null) for (Map.Entry<String, String> e : hdr.entrySet()) req.append(e.getKey()).append(": ").append(e.getValue()).append("\r\n");
            req.append("\r\n");
            s.getOutputStream().write(req.toString().getBytes(StandardCharsets.UTF_8));
            s.getOutputStream().flush();
            InputStream in = s.getInputStream();
            String status = line(in);
            Resp r = new Resp();
            r.url = url;
            String[] sp = status.split(" ");
            r.code = sp.length > 1 ? Integer.parseInt(sp[1]) : 0;
            String l;
            while (!(l = line(in)).isEmpty()) {
                int c = l.indexOf(':');
                if (c > 0) r.headers.put(l.substring(0, c).trim().toLowerCase(Locale.ROOT), l.substring(c + 1).trim());
            }
            if (r.code >= 300 && r.code < 400 && !r.header("location").isEmpty())
                return viaSocks(new URL(u, r.header("location")).toString(), hdr, timeout, k, maxBytes, hop + 1);
            if (r.header("transfer-encoding").toLowerCase(Locale.ROOT).contains("chunked")) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                while (true) {
                    String sz = line(in).trim();
                    int semi = sz.indexOf(';');
                    if (semi >= 0) sz = sz.substring(0, semi);
                    int n = Integer.parseInt(sz, 16);
                    if (n == 0) break;
                    byte[] b = new byte[n];
                    readFully(in, b);
                    bo.write(b);
                    if (bo.size() > maxBytes) throw new IOException("ответ слишком большой");
                    line(in);
                }
                r.body = bo.toByteArray();
            } else if (!r.header("content-length").isEmpty()) {
                int n = Integer.parseInt(r.header("content-length"));
                if (n > maxBytes) throw new IOException("ответ слишком большой");
                r.body = new byte[n];
                readFully(in, r.body);
            } else r.body = readAll(in, maxBytes);
            return r;
        } finally { try { s.close(); } catch (Exception ignored) { } }
    }

    static String line(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') bo.write(c);
            if (bo.size() > 65536) throw new IOException("слишком длинная строка ответа");
        }
        if (c < 0 && bo.size() == 0) throw new IOException("сервер закрыл соединение");
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }

    /* ======================= certificate pin for "allowInsecure" links ======================= */
    /** SHA-256 of the server's leaf certificate (hex) — Xray dropped allowInsecure in favour of pinning */
    public static String certSha256(String host, int port, String sni, int timeout) throws Exception {
        TrustManager[] all = {new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] c, String a) { }
            public void checkServerTrusted(X509Certificate[] c, String a) { }
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        }};
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, all, new java.security.SecureRandom());
        try (Socket raw = new Socket()) {
            raw.connect(new InetSocketAddress(host, port), timeout);
            raw.setSoTimeout(timeout);
            SSLSocket s = (SSLSocket) ctx.getSocketFactory().createSocket(raw, sni == null || sni.isEmpty() ? host : sni, port, true);
            s.startHandshake();
            Certificate[] chain = s.getSession().getPeerCertificates();
            byte[] d = MessageDigest.getInstance("SHA-256").digest(chain[0].getEncoded());
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            s.close();
            return sb.toString();
        }
    }

    /** plain TCP connect time in ms, -1 when unreachable */
    public static long tcpPing(String host, int port, int timeout) {
        long t0 = System.nanoTime();
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), timeout);
            return Math.max(1, (System.nanoTime() - t0) / 1_000_000);
        } catch (Exception e) { return -1; }
    }
}
