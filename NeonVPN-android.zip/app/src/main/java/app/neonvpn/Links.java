package app.neonvpn;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Share links (vless://, vmess://, trojan://, ss://, socks://, hysteria2://) <-> profile JSON.
 * Pure Java so it can be tested on a desktop JVM.
 */
public final class Links {
    private Links() { }

    /* ======================= encoding helpers ======================= */
    /** percent-decoding that keeps '+' (paths and passwords use it literally) */
    public static String pdec(String s) {
        if (s == null || s.indexOf('%') < 0) return s == null ? "" : s;
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        for (int i = 0; i < b.length; i++) {
            if (b[i] == '%' && i + 2 < b.length) {
                int hi = Character.digit(b[i + 1], 16), lo = Character.digit(b[i + 2], 16);
                if (hi >= 0 && lo >= 0) { bo.write(hi * 16 + lo); i += 2; continue; }
            }
            bo.write(b[i]);
        }
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }

    public static String penc(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (byte x : s.getBytes(StandardCharsets.UTF_8)) {
            int c = x & 0xff;
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || "-_.!~*'()".indexOf(c) >= 0) sb.append((char) c);
            else sb.append('%').append(String.format("%02X", c));
        }
        return sb.toString();
    }

    /** lenient base64 (standard or url-safe, with or without padding); null when it is not base64 */
    public static String b64(String s) {
        if (s == null) return null;
        String t = s.replaceAll("\\s", "").replace('-', '+').replace('_', '/');
        if (t.isEmpty() || !t.matches("[A-Za-z0-9+/=]+")) return null;
        t = t.replace("=", "");
        while (t.length() % 4 != 0) t += "=";
        try { return new String(Base64.getDecoder().decode(t), StandardCharsets.UTF_8); } catch (Exception e) { return null; }
    }

    public static String b64enc(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }

    /* ======================= URI ======================= */
    static final class U {
        String scheme = "", user = "", host = "", query = "", frag = "";
        int port = -1;
        final Map<String, String> q = new LinkedHashMap<>();
        String q(String k) { String v = q.get(k); return v == null ? "" : v; }
    }

    static U uri(String s) {
        U u = new U();
        int i = s.indexOf("://");
        if (i < 0) return null;
        u.scheme = s.substring(0, i).toLowerCase(Locale.ROOT);
        String rest = s.substring(i + 3);
        int h = rest.indexOf('#');
        if (h >= 0) { u.frag = pdec(rest.substring(h + 1)); rest = rest.substring(0, h); }
        int qm = rest.indexOf('?');
        if (qm >= 0) { u.query = rest.substring(qm + 1); rest = rest.substring(0, qm); }
        String hp;
        int at = rest.lastIndexOf('@');
        if (at >= 0) { u.user = rest.substring(0, at); hp = rest.substring(at + 1); } else hp = rest;
        int sl = hp.indexOf('/');
        if (sl >= 0) hp = hp.substring(0, sl);
        if (hp.startsWith("[")) {
            int e = hp.indexOf(']');
            if (e < 0) return null;
            u.host = hp.substring(1, e);
            if (e + 1 < hp.length() && hp.charAt(e + 1) == ':') u.port = num(hp.substring(e + 2), -1);
        } else {
            int c = hp.lastIndexOf(':');
            if (c >= 0) { u.host = hp.substring(0, c); u.port = num(hp.substring(c + 1), -1); } else u.host = hp;
        }
        u.host = pdec(u.host).trim();
        for (String kv : u.query.split("&")) {
            if (kv.isEmpty()) continue;
            int e = kv.indexOf('=');
            String k = e >= 0 ? kv.substring(0, e) : kv, v = e >= 0 ? kv.substring(e + 1) : "";
            u.q.put(pdec(k), pdec(v));
        }
        return u;
    }

    static int num(String s, int d) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return d; } }

    static void put(JSONObject o, String k, String v) {
        try { if (v != null && !v.isEmpty()) o.put(k, v); } catch (Exception ignored) { }
    }

    static JSONObject base(String proto, U u) throws Exception {
        if (u.host.isEmpty() || u.port <= 0 || u.port > 65535) throw new Exception("нет адреса или порта сервера");
        JSONObject p = new JSONObject();
        p.put("proto", proto);
        p.put("addr", u.host);
        p.put("port", u.port);
        p.put("name", u.frag.isEmpty() ? u.host + ":" + u.port : u.frag.trim());
        return p;
    }

    /** common transport/TLS query keys (v2rayN/v2rayNG share-link standard) */
    static void fromQuery(JSONObject p, U u) {
        String net = u.q("type").toLowerCase(Locale.ROOT);
        put(p, "net", net.isEmpty() ? "tcp" : net);
        put(p, "htype", u.q("headerType"));
        put(p, "host", u.q("host"));
        put(p, "path", u.q("path"));
        put(p, "seed", u.q("seed"));
        put(p, "mode", u.q("mode"));
        put(p, "svc", u.q("serviceName"));
        put(p, "auth", u.q("authority"));
        put(p, "extra", u.q("extra"));
        put(p, "fm", u.q("fm"));
        String sec = u.q("security").toLowerCase(Locale.ROOT);
        if (sec.equals("tls") || sec.equals("reality")) put(p, "sec", sec);
        for (String k : new String[]{"insecure", "allowInsecure", "allow_insecure"}) if (u.q(k).equals("1") || u.q(k).equalsIgnoreCase("true")) try { p.put("insecure", true); } catch (Exception ignored) { }
        put(p, "sni", u.q("sni").isEmpty() ? u.q("peer") : u.q("sni"));
        put(p, "fp", u.q("fp"));
        put(p, "alpn", u.q("alpn"));
        put(p, "ech", u.q("ech"));
        put(p, "vcn", u.q("vcn"));
        put(p, "pcs", u.q("pcs"));
        put(p, "pbk", u.q("pbk"));
        put(p, "sid", u.q("sid"));
        put(p, "spx", u.q("spx"));
        put(p, "pqv", u.q("pqv"));
        put(p, "flow", u.q("flow"));
    }

    /* ======================= parsing ======================= */
    public static boolean isLink(String s) {
        String l = s.trim().toLowerCase(Locale.ROOT);
        return l.startsWith("vless://") || l.startsWith("vmess://") || l.startsWith("trojan://") || l.startsWith("ss://") || l.startsWith("socks://") || l.startsWith("socks5://")
                || l.startsWith("hysteria2://") || l.startsWith("hy2://");
    }

    /** one share link -> profile; throws with a human readable reason */
    public static JSONObject parse(String link) throws Exception {
        String s = link.trim();
        String l = s.toLowerCase(Locale.ROOT);
        JSONObject p;
        if (l.startsWith("vmess://")) p = vmess(s);
        else if (l.startsWith("ss://")) p = ss(s);
        else {
            U u = uri(s);
            if (u == null) throw new Exception("непонятная ссылка");
            switch (u.scheme) {
                case "vless": {
                    p = base("vless", u);
                    p.put("uuid", pdec(u.user));
                    put(p, "enc", u.q("encryption").isEmpty() ? "none" : u.q("encryption"));
                    fromQuery(p, u);
                    break;
                }
                case "trojan": {
                    p = base("trojan", u);
                    p.put("pass", pdec(u.user));
                    fromQuery(p, u);
                    if (!p.has("sec")) p.put("sec", u.q("security").equalsIgnoreCase("none") ? "none" : "tls");
                    break;
                }
                case "socks": case "socks5": {
                    p = base("socks", u);
                    userPass(p, u.user);
                    break;
                }
                case "hysteria2": case "hy2": {
                    p = base("hy2", u);
                    p.put("pass", pdec(u.user));
                    fromQuery(p, u);
                    p.put("net", "hysteria");
                    if (!p.has("sec")) p.put("sec", "tls");
                    put(p, "obfs", u.q("obfs-password"));
                    put(p, "pcs", u.q("pinSHA256"));
                    put(p, "up", u.q("upmbps"));
                    put(p, "down", u.q("downmbps"));
                    break;
                }
                default:
                    throw new Exception("протокол " + u.scheme + " не поддерживается");
            }
        }
        p.put("link", s);
        return p;
    }

    static void userPass(JSONObject p, String user) throws Exception {
        if (user == null || user.isEmpty()) return;
        String up = pdec(user);
        if (!up.contains(":")) { String d = b64(user); if (d != null && d.contains(":")) up = d; }
        int c = up.indexOf(':');
        if (c > 0) { p.put("user", up.substring(0, c)); p.put("pass", up.substring(c + 1)); }
    }

    static JSONObject vmess(String s) throws Exception {
        String body = s.substring(8);
        if (body.contains("@") && body.contains("?")) {
            // "standard" vmess://uuid@host:port?type=...
            U u = uri(s);
            JSONObject p = base("vmess", u);
            p.put("uuid", pdec(u.user));
            p.put("method", u.q("encryption").isEmpty() ? "auto" : u.q("encryption"));
            fromQuery(p, u);
            return p;
        }
        int h = body.indexOf('#');
        String frag = null;
        if (h >= 0) { frag = pdec(body.substring(h + 1)); body = body.substring(0, h); }
        String js = b64(body);
        if (js == null) throw new Exception("vmess-ссылка повреждена");
        JSONObject v = new JSONObject(js.trim());
        JSONObject p = new JSONObject();
        p.put("proto", "vmess");
        String add = v.optString("add").trim();
        int port = num(v.optString("port"), -1);
        if (add.isEmpty() || port <= 0) throw new Exception("нет адреса или порта сервера");
        p.put("addr", add);
        p.put("port", port);
        String ps = v.optString("ps").trim();
        p.put("name", frag != null && !frag.isEmpty() ? frag : ps.isEmpty() ? add + ":" + port : ps);
        p.put("uuid", v.optString("id"));
        p.put("method", v.optString("scy").isEmpty() ? "auto" : v.optString("scy"));
        String net = v.optString("net", "tcp").toLowerCase(Locale.ROOT);
        p.put("net", net.isEmpty() ? "tcp" : net);
        put(p, "htype", v.optString("type"));
        put(p, "host", v.optString("host"));
        put(p, "path", v.optString("path"));
        if (net.equals("kcp")) put(p, "seed", v.optString("path"));
        if (net.equals("grpc")) { put(p, "mode", v.optString("type")); put(p, "svc", v.optString("path")); put(p, "auth", v.optString("host")); }
        String tls = v.optString("tls").toLowerCase(Locale.ROOT);
        if (tls.equals("tls") || tls.equals("reality")) p.put("sec", tls);
        put(p, "sni", v.optString("sni"));
        put(p, "alpn", v.optString("alpn"));
        put(p, "fp", v.optString("fp"));
        if ("1".equals(v.optString("insecure")) || "true".equalsIgnoreCase(v.optString("allowInsecure"))) p.put("insecure", true);
        return p;
    }

    static JSONObject ss(String s) throws Exception {
        U u = uri(s);
        if (u != null && !u.user.isEmpty() && !u.host.isEmpty() && u.port > 0) {
            // SIP002: ss://base64(method:pass)@host:port or ss://method:pass@host:port (2022 ciphers)
            JSONObject p = base("ss", u);
            String up = pdec(u.user);
            if (!up.contains(":")) { String d = b64(u.user); if (d != null) up = d; }
            int c = up.indexOf(':');
            if (c <= 0) throw new Exception("в ss-ссылке нет шифра и пароля");
            p.put("method", up.substring(0, c).toLowerCase(Locale.ROOT));
            p.put("pass", up.substring(c + 1));
            String plugin = u.q("plugin");
            if (plugin.contains("obfs=http")) {
                p.put("net", "tcp");
                p.put("htype", "http");
                for (String kv : plugin.split(";")) {
                    if (kv.startsWith("obfs-host=")) p.put("host", kv.substring(10));
                    if (kv.startsWith("path=")) p.put("path", kv.substring(5));
                }
            } else if (!plugin.isEmpty()) throw new Exception("плагин Shadowsocks «" + plugin.split(";")[0] + "» не поддерживается");
            return p;
        }
        // legacy: ss://base64(method:pass@host:port)#name
        String body = s.substring(5);
        String frag = "";
        int h = body.indexOf('#');
        if (h >= 0) { frag = pdec(body.substring(h + 1)); body = body.substring(0, h); }
        int at = body.indexOf('@');
        String dec = at > 0 ? b64(body.substring(0, at)) + body.substring(at) : b64(body);
        if (dec == null) throw new Exception("ss-ссылка повреждена");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(.+?):(.*)@(.+?):(\\d+)/?$").matcher(dec.trim());
        if (!m.matches()) throw new Exception("ss-ссылка повреждена");
        JSONObject p = new JSONObject();
        p.put("proto", "ss");
        String host = m.group(3).replaceAll("^\\[|]$", "");
        p.put("addr", host);
        p.put("port", Integer.parseInt(m.group(4)));
        p.put("method", m.group(1).toLowerCase(Locale.ROOT));
        p.put("pass", m.group(2));
        p.put("name", frag.isEmpty() ? host + ":" + m.group(4) : frag);
        return p;
    }

    /* ======================= many at once (paste, subscription body) ======================= */
    public static final class Result {
        public final List<JSONObject> items = new ArrayList<>();
        public final List<String> errors = new ArrayList<>();
        public final List<String> subs = new ArrayList<>();
    }

    /** text with links, a base64 subscription body, Xray JSON (one config or an array), or subscription URLs */
    public static Result parseText(String text) {
        Result r = new Result();
        if (text == null) return r;
        String t = text.replace("﻿", "").trim();
        if (t.isEmpty()) return r;
        if (t.startsWith("{") || t.startsWith("[")) {
            try { jsonConfigs(t, r); if (!r.items.isEmpty() || !r.errors.isEmpty()) return r; } catch (Exception e) { r.errors.add("JSON: " + e.getMessage()); return r; }
        }
        if (!t.contains("://")) {
            String d = b64(t);
            if (d != null && d.contains("://")) t = d.trim();
            else if (d != null && (d.trim().startsWith("{") || d.trim().startsWith("["))) { try { jsonConfigs(d.trim(), r); } catch (Exception e) { r.errors.add("JSON: " + e.getMessage()); } return r; }
        }
        if (t.startsWith("proxies:") || t.contains("\nproxies:")) { r.errors.add("Это конфиг Clash — нужен список ссылок или Xray JSON"); return r; }
        for (String line : t.split("[\\r\\n\\s]+")) {
            String x = line.trim();
            if (x.isEmpty()) continue;
            String lx = x.toLowerCase(Locale.ROOT);
            if (lx.startsWith("http://") || lx.startsWith("https://")) { r.subs.add(x); continue; }
            if (!isLink(x)) {
                if (x.contains("://")) r.errors.add(x.substring(0, x.indexOf("://")) + ": протокол не поддерживается");
                continue;
            }
            try { r.items.add(parse(x)); } catch (Exception e) { r.errors.add(shortName(x) + ": " + e.getMessage()); }
        }
        return r;
    }

    static String shortName(String link) {
        int h = link.indexOf('#');
        if (h >= 0 && h + 1 < link.length()) return pdec(link.substring(h + 1));
        return link.length() > 40 ? link.substring(0, 40) + "…" : link;
    }

    static void jsonConfigs(String t, Result r) throws Exception {
        JSONArray arr = t.startsWith("[") ? new JSONArray(t) : new JSONArray().put(new JSONObject(t));
        for (int i = 0; i < arr.length(); i++) {
            JSONObject c = arr.optJSONObject(i);
            if (c == null || !c.has("outbounds")) continue;
            JSONObject p = new JSONObject();
            p.put("proto", "custom");
            String name = c.optString("remarks").trim();
            JSONObject first = firstProxy(c);
            if (name.isEmpty()) name = first != null ? first.optString("protocol") + " " + serverOf(first) : "Конфиг " + (i + 1);
            p.put("name", name);
            p.put("cfg", c.toString());
            if (first != null) {
                p.put("addr", serverOf(first));
                p.put("port", portOf(first));
                p.put("inner", first.optString("protocol"));
            }
            r.items.add(p);
        }
        if (r.items.isEmpty()) r.errors.add("в JSON нет раздела outbounds");
    }

    static JSONObject firstProxy(JSONObject cfg) {
        JSONArray o = cfg.optJSONArray("outbounds");
        if (o == null) return null;
        for (int i = 0; i < o.length(); i++) {
            JSONObject x = o.optJSONObject(i);
            if (x == null) continue;
            String pr = x.optString("protocol");
            if (!pr.equals("freedom") && !pr.equals("blackhole") && !pr.equals("dns") && !pr.equals("loopback")) return x;
        }
        return null;
    }

    static String serverOf(JSONObject ob) {
        JSONObject s = ob.optJSONObject("settings");
        if (s == null) return "";
        if (s.has("address")) return s.optString("address");
        for (String k : new String[]{"vnext", "servers", "peers"}) {
            JSONArray a = s.optJSONArray(k);
            if (a != null && a.length() > 0) {
                JSONObject x = a.optJSONObject(0);
                if (x.has("address")) return x.optString("address");
                if (x.has("endpoint")) { String e = x.optString("endpoint"); int c = e.lastIndexOf(':'); return c > 0 ? e.substring(0, c) : e; }
            }
        }
        return "";
    }

    static int portOf(JSONObject ob) {
        JSONObject s = ob.optJSONObject("settings");
        if (s == null) return 0;
        if (s.has("port")) return s.optInt("port");
        for (String k : new String[]{"vnext", "servers"}) {
            JSONArray a = s.optJSONArray(k);
            if (a != null && a.length() > 0) return a.optJSONObject(0).optInt("port");
        }
        return 0;
    }

    /** stable identity of a server (keeps ids/pings across subscription updates) */
    public static String key(JSONObject p) {
        if ("custom".equals(p.optString("proto"))) return "custom|" + p.optString("name") + "|" + p.optString("cfg").hashCode();
        return p.optString("proto") + "|" + p.optString("addr").toLowerCase(Locale.ROOT) + "|" + p.optInt("port") + "|" + p.optString("uuid") + p.optString("pass")
                + "|" + p.optString("net") + "|" + p.optString("path") + "|" + p.optString("svc") + "|" + p.optString("sni") + "|" + p.optString("pbk") + "|" + p.optString("sid");
    }

    /* ======================= profile -> link ======================= */
    public static String toLink(JSONObject p) throws Exception {
        String proto = p.optString("proto");
        String host = p.optString("addr");
        String hp = (host.contains(":") ? "[" + host + "]" : host) + ":" + p.optInt("port");
        String name = "#" + penc(p.optString("name"));
        switch (proto) {
            case "vless": {
                Map<String, String> q = query(p);
                q.put("encryption", p.optString("enc", "none"));
                return "vless://" + penc(p.optString("uuid")) + "@" + hp + "?" + qs(q) + name;
            }
            case "trojan":
                return "trojan://" + penc(p.optString("pass")) + "@" + hp + "?" + qs(query(p)) + name;
            case "hy2": {
                Map<String, String> q = new LinkedHashMap<>();
                if (!p.optString("sni").isEmpty()) q.put("sni", p.optString("sni"));
                if (p.optBoolean("insecure")) q.put("insecure", "1");
                if (!p.optString("obfs").isEmpty()) { q.put("obfs", "salamander"); q.put("obfs-password", p.optString("obfs")); }
                if (!p.optString("pcs").isEmpty()) q.put("pinSHA256", p.optString("pcs"));
                return "hysteria2://" + penc(p.optString("pass")) + "@" + hp + (q.isEmpty() ? "" : "?" + qs(q)) + name;
            }
            case "ss":
                return "ss://" + b64enc(p.optString("method") + ":" + p.optString("pass")).replace("=", "") + "@" + hp + name;
            case "socks":
                return "socks://" + (p.optString("user").isEmpty() ? "" : b64enc(p.optString("user") + ":" + p.optString("pass")).replace("=", "") + "@") + hp + name;
            case "vmess": {
                JSONObject v = new JSONObject();
                v.put("v", "2"); v.put("ps", p.optString("name")); v.put("add", host); v.put("port", String.valueOf(p.optInt("port")));
                v.put("id", p.optString("uuid")); v.put("aid", "0"); v.put("scy", p.optString("method", "auto"));
                String net = p.optString("net", "tcp");
                v.put("net", net); v.put("type", net.equals("grpc") ? p.optString("mode", "gun") : p.optString("htype", "none"));
                v.put("host", net.equals("grpc") ? p.optString("auth") : p.optString("host"));
                v.put("path", net.equals("grpc") ? p.optString("svc") : net.equals("kcp") ? p.optString("seed") : p.optString("path"));
                v.put("tls", p.optString("sec").equals("tls") ? "tls" : "");
                v.put("sni", p.optString("sni")); v.put("alpn", p.optString("alpn")); v.put("fp", p.optString("fp"));
                return "vmess://" + b64enc(v.toString());
            }
            default:
                throw new Exception("для этого сервера нет ссылки");
        }
    }

    static Map<String, String> query(JSONObject p) {
        Map<String, String> q = new LinkedHashMap<>();
        String sec = p.optString("sec");
        q.put("security", sec.isEmpty() ? "none" : sec);
        for (String[] k : new String[][]{{"sni", "sni"}, {"fp", "fp"}, {"alpn", "alpn"}, {"pbk", "pbk"}, {"sid", "sid"}, {"spx", "spx"}, {"pqv", "pqv"}, {"flow", "flow"}, {"ech", "ech"}, {"vcn", "vcn"}, {"pcs", "pcs"}, {"fm", "fm"}})
            if (!p.optString(k[0]).isEmpty()) q.put(k[1], p.optString(k[0]));
        if (sec.equals("tls") && p.optBoolean("insecure")) q.put("allowInsecure", "1");
        String net = p.optString("net", "tcp");
        q.put("type", net);
        switch (net) {
            case "tcp": case "raw":
                q.put("headerType", p.optString("htype", "none"));
                if (!p.optString("host").isEmpty()) q.put("host", p.optString("host"));
                break;
            case "ws": case "httpupgrade":
                if (!p.optString("host").isEmpty()) q.put("host", p.optString("host"));
                if (!p.optString("path").isEmpty()) q.put("path", p.optString("path"));
                break;
            case "xhttp": case "splithttp":
                if (!p.optString("host").isEmpty()) q.put("host", p.optString("host"));
                if (!p.optString("path").isEmpty()) q.put("path", p.optString("path"));
                if (!p.optString("mode").isEmpty()) q.put("mode", p.optString("mode"));
                if (!p.optString("extra").isEmpty()) q.put("extra", p.optString("extra"));
                break;
            case "grpc":
                if (!p.optString("mode").isEmpty()) q.put("mode", p.optString("mode"));
                if (!p.optString("auth").isEmpty()) q.put("authority", p.optString("auth"));
                q.put("serviceName", p.optString("svc"));
                break;
            case "kcp":
                q.put("headerType", p.optString("htype", "none"));
                if (!p.optString("seed").isEmpty()) q.put("seed", p.optString("seed"));
                break;
            default:
        }
        return q;
    }

    static String qs(Map<String, String> q) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : q.entrySet()) { if (sb.length() > 0) sb.append('&'); sb.append(e.getKey()).append('=').append(penc(e.getValue())); }
        return sb.toString();
    }
}
