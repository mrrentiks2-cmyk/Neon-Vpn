package app.neonvpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

import libv2ray.CoreController;

/** The VPN: a TUN interface handed to Xray-core. Our own app is excluded, so Xray's sockets go out directly. */
public class NeonVpnService extends VpnService {
    static final String ACT_START = "app.neonvpn.START", ACT_STOP = "app.neonvpn.STOP";
    static final String CH = "vpn";
    static final int NID = 1;
    static final String[] ROUTED_V4 = {"0.0.0.0/5", "8.0.0.0/7", "11.0.0.0/8", "12.0.0.0/6", "16.0.0.0/4", "32.0.0.0/3", "64.0.0.0/2", "128.0.0.0/3", "160.0.0.0/5", "168.0.0.0/6",
            "172.0.0.0/12", "172.32.0.0/11", "172.64.0.0/10", "172.128.0.0/9", "173.0.0.0/8", "174.0.0.0/7", "176.0.0.0/4", "192.0.0.0/9", "192.128.0.0/11", "192.160.0.0/13",
            "192.169.0.0/16", "192.170.0.0/15", "192.172.0.0/14", "192.176.0.0/12", "192.192.0.0/10", "193.0.0.0/8", "194.0.0.0/7", "196.0.0.0/6", "200.0.0.0/5", "208.0.0.0/4", "240.0.0.0/4"};

    VpnCore core;
    ParcelFileDescriptor pfd;
    volatile boolean running;
    final Handler ui = new Handler(Looper.getMainLooper());
    Runnable ticker;
    ConnectivityManager.NetworkCallback netCb;
    int tick;

    static void start(Context c) {
        Intent i = new Intent(c, NeonVpnService.class).setAction(ACT_START);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void stop(Context c) {
        c.startService(new Intent(c, NeonVpnService.class).setAction(ACT_STOP));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        core = VpnCore.get(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? ACT_START : intent.getAction();
        if (ACT_STOP.equals(a)) {
            core.svc.execute(() -> stopVpn(""));
            return START_NOT_STICKY;
        }
        // ACT_START, or "android.net.VpnService" when the system starts us for always-on VPN
        startForeground(NID, notification("Подключение…", ""));
        core.svc.execute(this::startVpn);
        return START_STICKY;
    }

    void startVpn() {
        if (running) stopCore();
        core.setState("connecting", "");
        core.resetTraffic();
        try {
            JSONObject rc = core.runConfig(true);
            String name = rc.optString("name");
            core.activeName = name;
            core.activeSel = rc.optString("sel");
            JSONObject s = core.settings;
            Builder b = new Builder();
            b.setSession(name.isEmpty() ? "Neon VPN" : name);
            b.setMtu(s.optInt("mtu", 1500));
            b.addAddress("10.10.14.1", 30);
            if (s.optBoolean("bypassLan", true)) for (String r : ROUTED_V4) { String[] x = r.split("/"); b.addRoute(x[0], Integer.parseInt(x[1])); }
            else b.addRoute("0.0.0.0", 0);
            // always capture IPv6 so it cannot leak around the tunnel; Xray drops it when IPv6 is off
            b.addAddress("fc00::10:10:14:1", 126);
            b.addRoute("::", 0);
            for (String d : s.optString("dns", "1.1.1.1").split("[,\\s]+")) if (d.matches("[0-9.]+|[0-9a-fA-F:]+")) try { b.addDnsServer(d); } catch (Exception ignored) { }
            String mode = s.optString("appsMode", "off");
            JSONArray apps = s.optJSONArray("apps");
            String self = getPackageName();
            if ("include".equals(mode) && apps != null && apps.length() > 0) {
                for (int i = 0; i < apps.length(); i++) if (!apps.optString(i).equals(self)) try { b.addAllowedApplication(apps.optString(i)); } catch (PackageManager.NameNotFoundException ignored) { }
            } else {
                b.addDisallowedApplication(self);
                if ("exclude".equals(mode) && apps != null) for (int i = 0; i < apps.length(); i++) try { b.addDisallowedApplication(apps.optString(i)); } catch (PackageManager.NameNotFoundException ignored) { }
            }
            if (Build.VERSION.SDK_INT >= 29) b.setMetered(false);
            pfd = b.establish();
            if (pfd == null) throw new Exception("Android не дал создать VPN — разрешите подключение в диалоге");
            CoreController c = core.controller();
            c.startLoop(rc.getString("cfg"), pfd.getFd());
            if (!c.getIsRunning()) throw new Exception("ядро Xray не запустилось");
            running = true;
            core.log("Подключено: " + name);
            core.setState("on", "");
            watchNetwork();
            startTicker();
            updateNotif(name, "");
        } catch (Throwable e) {
            String msg = friendly(e);
            core.log("Ошибка подключения: " + msg);
            stopCore();
            core.setState("off", msg);
            stopForeground(true);
            stopSelf();
        }
    }

    static String friendly(Throwable e) {
        String m = String.valueOf(e.getMessage());
        String l = m.toLowerCase(Locale.ROOT);
        if (l.contains("config error") || l.contains("failed to")) return "Ошибка конфигурации: " + m;
        return m;
    }

    void stopCore() {
        running = false;
        ui.removeCallbacksAndMessages(null);
        try { core.controller().stopLoop(); } catch (Throwable ignored) { }
        if (pfd != null) { try { pfd.close(); } catch (Exception ignored) { } pfd = null; }
        if (netCb != null) {
            try { getSystemService(ConnectivityManager.class).unregisterNetworkCallback(netCb); } catch (Exception ignored) { }
            netCb = null;
        }
    }

    void stopVpn(String reason) {
        boolean was = running || "connecting".equals(core.state);
        stopCore();
        if (was) core.log(reason.isEmpty() ? "Отключено" : reason);
        core.setState("off", reason);
        ui.post(() -> { stopForeground(true); stopSelf(); });
    }

    @Override
    public void onRevoke() {
        core.svc.execute(() -> stopVpn("VPN отключён системой — возможно, запущен другой VPN"));
    }

    @Override
    public void onDestroy() {
        if (running) { stopCore(); core.setState("off", ""); }
        super.onDestroy();
    }

    /** keep Android informed about the real network under the tunnel (metered state, validation) */
    void watchNetwork() {
        try {
            ConnectivityManager cm = getSystemService(ConnectivityManager.class);
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network n) { setUnderlyingNetworks(new Network[]{n}); }
                @Override public void onLost(Network n) { setUnderlyingNetworks(null); }
            };
            cm.registerDefaultNetworkCallback(netCb);
        } catch (Exception ignored) { }
    }

    void startTicker() {
        ticker = new Runnable() {
            @Override public void run() {
                if (!running) return;
                core.svc.execute(() -> {
                    if (!running) return;
                    try { core.onStats(core.controller().queryAllOutboundTrafficStats()); } catch (Throwable ignored) { }
                    if (++tick % 2 == 0) updateNotif(core.activeName, "↓ " + speed(core.downSpeed) + "   ↑ " + speed(core.upSpeed));
                });
                ui.postDelayed(this, 1000);
            }
        };
        ui.postDelayed(ticker, 1000);
    }

    static String speed(long b) {
        if (b < 1024) return b + " Б/с";
        if (b < 1024 * 1024) return String.format(Locale.ROOT, "%.0f КБ/с", b / 1024.0);
        return String.format(Locale.ROOT, "%.1f МБ/с", b / 1048576.0).replace('.', ',');
    }

    /* ======================= notification ======================= */
    Notification notification(String title, String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "VPN-подключение", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, NeonVpnService.class).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder((android.graphics.drawable.Icon) null, "Отключить", stop).build());
        if (running && core.since > 0) b.setWhen(core.since).setUsesChronometer(true).setShowWhen(true);
        return b.build();
    }

    void updateNotif(String name, String text) {
        try { getSystemService(NotificationManager.class).notify(NID, notification(name.isEmpty() ? "Neon VPN" : name, text.isEmpty() ? "Защищённое подключение" : text)); } catch (Exception ignored) { }
    }
}
