package app.neonvpn;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.net.ServerSocket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import libv2ray.CoreCallbackHandler;
import libv2ray.CoreController;
import libv2ray.Libv2ray;

/** App-wide state: servers, subscriptions, settings, the Xray core and the VPN status. */
final class VpnCore {
    interface Listener { void emit(JSONObject e); }

    private static VpnCore inst;

    static synchronized VpnCore get(Context c) {
        if (inst == null) inst = new VpnCore(c.getApplicationContext());
        return inst;
    }

    final Context ctx;
    final SharedPreferences prefs;
    final ExecutorService io = Executors.newFixedThreadPool(4), svc = Executors.newSingleThreadExecutor();
    ExecutorService pingPool = Executors.newFixedThreadPool(6);
    final List<JSONObject> profiles = new ArrayList<>();
    final List<JSONObject> subs = new ArrayList<>();
    JSONObject settings;
    volatile Listener listener;
    final Map<String, String> pins = new ConcurrentHashMap<>();
    final ArrayDeque<String> logs = new ArrayDeque<>();
    final AtomicInteger pingGen = new AtomicInteger();
    final SecureRandom rnd = new SecureRandom();

    // runtime
    volatile String state = "off", error = "", activeName = "", activeSel = "";
    volatile long since, upTotal, downTotal, upSpeed, downSpeed, directTotal;
    volatile XrayConfig.Socks socks;
    private CoreController controller;
    private boolean coreReady;

    static final String[] DEFAULTS = {
            "route", "ru", "blockAds", "false", "blockQuic", "true", "ipv6", "false", "sniff", "true", "mux", "false", "fragment", "false",
            "bypassLan", "true", "dns", "1.1.1.1", "mtu", "1500", "testUrl", "https://www.gstatic.com/generate_204", "localSocks", "true",
            "ua", "", "hwid", "true", "appsMode", "off", "logLevel", "warning", "autoUpdate", "true", "pingMode", "real"};

    private VpnCore(Context c) {
        ctx = c;
        prefs = c.getSharedPreferences("vpn", Context.MODE_PRIVATE);
        load();
    }

    /* ======================= storage ======================= */
    File file(String n) { return new File(ctx.getFilesDir(), n); }

    static JSONArray readArr(File f) {
        try { return new JSONArray(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8)); } catch (Exception e) { return new JSONArray(); }
    }

    static void writeAtomic(File f, String s) {
        try {
            File tmp = new File(f.getPath() + ".tmp");
            try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(s.getBytes(StandardCharsets.UTF_8)); o.getFD().sync(); }
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f); }
        } catch (Exception ignored) { }
    }

    synchronized void load() {
        profiles.clear(); subs.clear();
        JSONArray a = readArr(file("profiles.json"));
        for (int i = 0; i < a.length(); i++) if (a.optJSONObject(i) != null) profiles.add(a.optJSONObject(i));
        a = readArr(file("subs.json"));
        for (int i = 0; i < a.length(); i++) if (a.optJSONObject(i) != null) subs.add(a.optJSONObject(i));
        try { settings = new JSONObject(prefs.getString("settings", "{}")); } catch (Exception e) { settings = new JSONObject(); }
        for (int i = 0; i < DEFAULTS.length; i += 2) {
            if (settings.has(DEFAULTS[i])) continue;
            String v = DEFAULTS[i + 1];
            try { settings.put(DEFAULTS[i], v.equals("true") ? Boolean.TRUE : v.equals("false") ? Boolean.FALSE : v.matches("\\d+") ? (Object) Integer.parseInt(v) : v); } catch (Exception ignored) { }
        }
        try { if (!settings.has("rules")) settings.put("rules", new JSONArray()); if (!settings.has("apps")) settings.put("apps", new JSONArray()); } catch (Exception ignored) { }
    }

    synchronized void saveProfiles() { JSONArray a = new JSONArray(); for (JSONObject p : profiles) a.put(p); writeAtomic(file("profiles.json"), a.toString()); }

    synchronized void saveSubs() { JSONArray a = new JSONArray(); for (JSONObject s : subs) a.put(s); writeAtomic(file("subs.json"), a.toString()); }

    synchronized void saveSettings() { prefs.edit().putString("settings", settings.toString()).apply(); }

    String newId() { byte[] b = new byte[6]; rnd.nextBytes(b); return Base64.encodeToString(b, Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP); }

    String hwid() {
        String h = prefs.getString("hwid", "");
        if (h.isEmpty()) { h = UUID.randomUUID().toString().replace("-", ""); prefs.edit().putString("hwid", h).apply(); }
        return h;
    }

    String xudpKey() {
        String k = prefs.getString("xudp", "");
        if (k.isEmpty()) { byte[] b = new byte[32]; rnd.nextBytes(b); k = Base64.encodeToString(b, Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP); prefs.edit().putString("xudp", k).apply(); }
        return k;
    }

    synchronized JSONObject profile(String id) { for (JSONObject p : profiles) if (p.optString("id").equals(id)) return p; return null; }

    synchronized JSONObject sub(String id) { for (JSONObject s : subs) if (s.optString("id").equals(id)) return s; return null; }

    String sel() { return prefs.getString("sel", ""); }

    /* ======================= events & log ======================= */
    void emit(JSONObject e) { Listener l = listener; if (l != null) l.emit(e); }

    static JSONObject ev(String t) { JSONObject o = new JSONObject(); try { o.put("type", t); } catch (Exception ignored) { } return o; }

    void log(String s) {
        String line = new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new Date()) + "  " + s;
        synchronized (logs) { logs.addLast(line); while (logs.size() > 300) logs.removeFirst(); }
        try { emit(ev("log").put("line", line)); } catch (Exception ignored) { }
    }

    JSONObject stateJson() {
        JSONObject o = ev("state");
        try {
            o.put("state", state); o.put("error", error); o.put("name", activeName); o.put("sel", activeSel); o.put("since", since);
            o.put("up", upTotal); o.put("down", downTotal); o.put("upSpeed", upSpeed); o.put("downSpeed", downSpeed);
        } catch (Exception ignored) { }
        return o;
    }

    void setState(String s, String err) {
        state = s;
        error = err == null ? "" : err;
        if (s.equals("on")) since = System.currentTimeMillis();
        if (s.equals("off")) { upSpeed = 0; downSpeed = 0; socks = null; }
        emit(stateJson());
        QsTile.refresh(ctx);
    }

    /* ======================= Xray core ======================= */
    synchronized void initCore() {
        if (coreReady) return;
        go.Seq.setContext(ctx);
        Libv2ray.initCoreEnv(ctx.getDir("xray", Context.MODE_PRIVATE).getAbsolutePath(), xudpKey());
        coreReady = true;
    }

    synchronized CoreController controller() {
        initCore();
        if (controller == null) controller = Libv2ray.newCoreController(new CoreCallbackHandler() {
            @Override public long startup() { return 0; }
            @Override public long shutdown() { return 0; }
            @Override public long onEmitStatus(long code, String msg) { if (msg != null && !msg.isEmpty()) log("Ядро: " + msg); return 0; }
        });
        return controller;
    }

    String coreVersion() { try { initCore(); return Libv2ray.checkVersionX(); } catch (Throwable t) { return "ядро не загружено: " + t.getMessage(); } }

    /* ======================= building the running config ======================= */
    List<JSONObject> group(String g) {
        List<JSONObject> l = new ArrayList<>();
        synchronized (this) {
            for (JSONObject p : profiles) {
                if ("custom".equals(p.optString("proto"))) continue;
                if (g.equals("all") || (g.equals("manual") && p.optString("sub").isEmpty()) || p.optString("sub").equals(g)) l.add(p);
            }
        }
        Collections.sort(l, (a, b) -> Long.compare(pingKey(a), pingKey(b)));
        return l;
    }

    static long pingKey(JSONObject p) { long v = p.optLong("ping", 0); return v > 0 ? v : v == 0 ? 100000 : 200000; }

    String groupName(String g) {
        if (g.equals("all")) return "все серверы";
        if (g.equals("manual")) return "мои серверы";
        JSONObject s = sub(g);
        return s == null ? "подписка" : s.optString("name");
    }

    String pinFor(JSONObject p) {
        if (!"tls".equals(p.optString("sec")) || !p.optBoolean("insecure") || !p.optString("pcs").isEmpty() || "hy2".equals(p.optString("proto"))) return null;
        String key = p.optString("addr") + ":" + p.optInt("port") + "/" + p.optString("sni");
        String v = pins.get(key);
        if (v != null) return v;
        try {
            v = Net.certSha256(p.optString("addr"), p.optInt("port"), p.optString("sni"), 5000);
            pins.put(key, v);
            log("Сертификат " + p.optString("name") + " закреплён (allowInsecure)");
            return v;
        } catch (Exception e) { log("Не удалось получить сертификат " + p.optString("name") + ": " + e.getMessage()); return null; }
    }

    static int freePort() { try (ServerSocket s = new ServerSocket(0)) { return s.getLocalPort(); } catch (Exception e) { return 10000 + new SecureRandom().nextInt(50000); } }

    /** {cfg, name, sel} for the VPN service */
    JSONObject runConfig(boolean apply) throws Exception { return runConfig(apply, null); }

    JSONObject runConfig(boolean apply, String override) throws Exception {
        String sel = override == null || override.isEmpty() ? sel() : override;
        List<JSONObject> chosen = new ArrayList<>();
        String name;
        if (sel.startsWith("auto:")) {
            String g = sel.substring(5);
            for (JSONObject p : group(g)) { if (chosen.size() >= 40) break; chosen.add(p); }
            name = "Автовыбор · " + groupName(g);
            if (chosen.size() == 1) name = chosen.get(0).optString("name");
        } else {
            JSONObject p = profile(sel);
            if (p == null) synchronized (this) { if (!profiles.isEmpty()) { p = profiles.get(0); sel = p.optString("id"); if (apply) prefs.edit().putString("sel", sel).apply(); } }
            if (p != null) chosen.add(p);
            name = p == null ? "" : p.optString("name");
        }
        if (chosen.isEmpty()) throw new Exception("Добавьте сервер или подписку");
        Map<String, String> pinMap = new HashMap<>();
        for (JSONObject p : chosen) { String v = pinFor(p); if (v != null) pinMap.put(p.optString("id"), v); }
        XrayConfig.Socks k = settings.optBoolean("localSocks", true) ? new XrayConfig.Socks(freePort(), "n" + newId(), newId() + newId()) : null;
        JSONObject cfg = XrayConfig.build(chosen, settings, true, k, pinMap);
        JSONObject r = new JSONObject();
        r.put("cfg", cfg.toString());
        r.put("name", name);
        r.put("sel", sel);
        if (apply) socks = k;
        return r;
    }

    /* ======================= traffic ======================= */
    long lastTick;

    /** "tag,uplink|downlink,bytes;..." since the previous call */
    void onStats(String s) {
        long up = 0, down = 0, direct = 0;
        if (s != null) for (String part : s.split(";")) {
            String[] f = part.split(",");
            if (f.length != 3) continue;
            long v;
            try { v = Long.parseLong(f[2]); } catch (Exception e) { continue; }
            if (f[0].startsWith("proxy")) { if (f[1].equals("uplink")) up += v; else down += v; }
            else if (f[0].equals("direct")) direct += v;
        }
        long now = System.currentTimeMillis();
        double sec = lastTick == 0 ? 1 : Math.max(0.5, (now - lastTick) / 1000.0);
        lastTick = now;
        upTotal += up; downTotal += down; directTotal += direct;
        upSpeed = (long) (up / sec); downSpeed = (long) (down / sec);
        try { emit(ev("stats").put("up", upTotal).put("down", downTotal).put("upSpeed", upSpeed).put("downSpeed", downSpeed).put("since", since)); } catch (Exception ignored) { }
    }

    void resetTraffic() { upTotal = 0; downTotal = 0; directTotal = 0; upSpeed = 0; downSpeed = 0; lastTick = 0; }

    /* ======================= servers & subscriptions ======================= */
    /** merge fresh subscription items keeping ids (selection) and pings of servers that did not change */
    synchronized int replaceSubProfiles(String subId, List<JSONObject> items) throws Exception {
        Map<String, JSONObject> old = new HashMap<>();
        List<JSONObject> keep = new ArrayList<>();
        for (JSONObject p : profiles) { if (p.optString("sub").equals(subId)) old.put(Links.key(p), p); else keep.add(p); }
        List<JSONObject> fresh = new ArrayList<>();
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (JSONObject p : items) {
            String k = Links.key(p);
            if (!seen.add(k)) continue;
            JSONObject o = old.get(k);
            p.put("id", o != null ? o.optString("id") : newId());
            p.put("sub", subId);
            if (o != null && o.has("ping")) p.put("ping", o.optLong("ping"));
            fresh.add(p);
        }
        // keep the subscription's position in the list
        int at = keep.size();
        for (int i = 0; i < profiles.size(); i++) if (profiles.get(i).optString("sub").equals(subId)) { at = 0; for (int j = 0; j < i; j++) if (!profiles.get(j).optString("sub").equals(subId)) at++; break; }
        profiles.clear();
        profiles.addAll(keep);
        profiles.addAll(Math.min(at, profiles.size()), fresh);
        saveProfiles();
        return fresh.size();
    }

    JSONObject updateSub(String id) throws Exception {
        JSONObject s = sub(id);
        if (s == null) throw new Exception("подписка не найдена");
        String ua = s.optString("ua").isEmpty() ? settings.optString("ua") : s.optString("ua");
        java.util.Map<String, String> h = Subs.headers(ua, settings.optBoolean("hwid", true) ? hwid() : null, Build.VERSION.RELEASE, Build.MANUFACTURER + " " + Build.MODEL);
        try {
            Subs.Fetched f = Subs.fetch(s.optString("url"), h, "on".equals(state) ? socks : null);
            int n = replaceSubProfiles(id, f.parsed.items);
            synchronized (this) {
                s.put("info", f.info);
                s.put("updated", System.currentTimeMillis());
                s.remove("error");
                if (f.info.has("title") && s.optBoolean("autoName", true)) s.put("name", f.info.optString("title"));
                if (f.info.has("interval")) s.put("interval", f.info.optInt("interval"));
                saveSubs();
            }
            log("Подписка «" + s.optString("name") + "» обновлена: " + n + " серв.");
            return new JSONObject().put("count", n).put("errors", new JSONArray(f.parsed.errors));
        } catch (Exception e) {
            synchronized (this) { s.put("error", e.getMessage()); s.put("tried", System.currentTimeMillis()); saveSubs(); }
            log("Подписка «" + s.optString("name") + "»: " + e.getMessage());
            throw e;
        }
    }

    JSONObject addSub(String url, String name, String ua) throws Exception {
        url = url.trim();
        synchronized (this) {
            for (JSONObject s : subs) if (s.optString("url").equals(url)) { updateSub(s.optString("id")); return new JSONObject().put("id", s.optString("id")).put("existed", true); }
        }
        JSONObject s = new JSONObject();
        String id = newId();
        s.put("id", id);
        s.put("url", url);
        s.put("name", name == null || name.trim().isEmpty() ? hostOf(url) : name.trim());
        s.put("autoName", name == null || name.trim().isEmpty());
        s.put("ua", ua == null ? "" : ua);
        s.put("auto", true);
        s.put("interval", 12);
        synchronized (this) { subs.add(s); saveSubs(); }
        try { updateSub(id); }
        catch (Exception e) { synchronized (this) { subs.remove(s); saveSubs(); } throw e; }
        if (sel().isEmpty()) prefs.edit().putString("sel", "auto:" + id).apply();
        return new JSONObject().put("id", id);
    }

    static String hostOf(String url) { try { return new java.net.URL(url).getHost(); } catch (Exception e) { return "Подписка"; } }

    /** paste / share / deep link: links, subscription URLs, base64 bodies, Xray JSON */
    JSONObject importText(String text) throws Exception {
        String t = text == null ? "" : text.trim();
        JSONObject dl = t.contains("://") && !Links.isLink(t) && !t.toLowerCase(Locale.ROOT).startsWith("http") ? Subs.deepLink(t) : null;
        if (dl != null) {
            String u = dl.optString("url");
            if (Links.isLink(u)) t = u;
            else { JSONObject r = addSub(u, dl.optString("name"), null); return new JSONObject().put("subs", 1).put("added", 0).put("subId", r.optString("id")); }
        }
        Links.Result r = Links.parseText(t);
        int subsAdded = 0;
        String subId = null;
        List<String> errors = new ArrayList<>(r.errors);
        for (String u : r.subs) {
            try { subId = addSub(u, null, null).optString("id"); subsAdded++; } catch (Exception e) { errors.add(u + ": " + e.getMessage()); }
        }
        String firstId = null;
        synchronized (this) {
            java.util.Set<String> have = new java.util.HashSet<>();
            for (JSONObject p : profiles) if (p.optString("sub").isEmpty()) have.add(Links.key(p));
            for (JSONObject p : r.items) {
                if (!have.add(Links.key(p))) continue;
                p.put("id", newId());
                p.put("sub", "");
                profiles.add(p);
                if (firstId == null) firstId = p.optString("id");
            }
            saveProfiles();
        }
        if (firstId != null && (sel().isEmpty() || profile(sel()) == null && !sel().startsWith("auto:"))) prefs.edit().putString("sel", firstId).apply();
        int added = firstId == null ? 0 : (int) r.items.stream().filter(p -> p.has("id")).count();
        if (added == 0 && subsAdded == 0 && errors.isEmpty()) errors.add("Не найдено ни одной ссылки на сервер или подписку");
        if (added == 0 && subsAdded == 0) throw new Exception(errors.get(0));
        return new JSONObject().put("added", added).put("subs", subsAdded).put("errors", new JSONArray(errors)).put("first", firstId == null ? "" : firstId).put("subId", subId == null ? "" : subId);
    }

    void autoUpdate(boolean force) {
        if (!force && !settings.optBoolean("autoUpdate", true)) return;
        List<String> due = new ArrayList<>();
        synchronized (this) {
            long now = System.currentTimeMillis();
            for (JSONObject s : subs) {
                if (!force && !s.optBoolean("auto", true)) continue;
                long iv = Math.max(1, s.optInt("interval", 12)) * 3600000L;
                long last = Math.max(s.optLong("updated"), s.optLong("tried"));
                if (force || now - last > iv) due.add(s.optString("id"));
            }
        }
        for (String id : due) io.execute(() -> {
            try { updateSub(id); emit(ev("data")); } catch (Exception e) { emit(ev("data")); }
        });
    }

    /* ======================= ping ======================= */
    long realDelay(JSONObject p) {
        try {
            initCore();
            String cfg = XrayConfig.speedtest(p, settings, pinFor(p));
            long ms = Libv2ray.measureOutboundDelay(cfg, settings.optString("testUrl", "https://www.gstatic.com/generate_204"));
            return ms > 0 ? ms : -1;
        } catch (Throwable t) { return -1; }
    }

    void ping(List<String> ids, String mode) {
        int gen = pingGen.incrementAndGet();
        AtomicInteger left = new AtomicInteger(ids.size());
        boolean tcp = "tcp".equals(mode);
        for (String id : ids) pingPool.execute(() -> {
            try {
                if (pingGen.get() != gen) return;
                JSONObject p = profile(id);
                if (p == null) return;
                long ms;
                if ("custom".equals(p.optString("proto")) && tcp) ms = p.optString("addr").isEmpty() ? -1 : Net.tcpPing(p.optString("addr"), p.optInt("port"), 3000);
                else ms = tcp ? Net.tcpPing(p.optString("addr"), p.optInt("port"), 3000) : realDelay(p);
                synchronized (this) { p.put("ping", ms); p.put("pingAt", System.currentTimeMillis()); }
                emit(ev("ping").put("id", id).put("ms", ms));
            } catch (Exception ignored) {
            } finally {
                if (left.decrementAndGet() == 0 && pingGen.get() == gen) { saveProfiles(); emit(ev("pingDone")); }
            }
        });
    }

    /* ======================= IP check ======================= */
    JSONObject ipInfo() throws Exception {
        XrayConfig.Socks k = "on".equals(state) ? socks : null;
        Map<String, String> h = new HashMap<>();
        h.put("User-Agent", "Mozilla/5.0 (Android) NeonVPN");
        Exception last = null;
        for (String url : new String[]{"https://ipwho.is/?lang=ru", "https://api.ip.sb/geoip", "https://ipinfo.io/json"}) {
            try {
                Net.Resp r = Net.get(url, h, 12000, k, 1 << 20);
                if (r.code != 200) continue;
                JSONObject j = new JSONObject(r.text());
                JSONObject o = new JSONObject();
                o.put("ip", j.optString("ip"));
                o.put("cc", j.optString("country_code", j.optString("country")).toUpperCase(Locale.ROOT));
                o.put("country", j.has("country_code") ? j.optString("country") : "");
                o.put("city", j.optString("city"));
                JSONObject conn = j.optJSONObject("connection");
                o.put("isp", conn != null ? conn.optString("isp", conn.optString("org")) : j.optString("isp", j.optString("organization", j.optString("org"))));
                o.put("via", k != null ? "vpn" : "direct");
                if (!o.optString("ip").isEmpty()) return o;
            } catch (Exception e) { last = e; }
        }
        throw new Exception("не удалось узнать IP" + (last == null ? "" : ": " + last.getMessage()));
    }

    /* ======================= installed apps ======================= */
    JSONArray apps() throws Exception {
        PackageManager pm = ctx.getPackageManager();
        List<ApplicationInfo> list = pm.getInstalledApplications(0);
        List<JSONObject> out = new ArrayList<>();
        for (ApplicationInfo ai : list) {
            if (ai.packageName.equals(ctx.getPackageName())) continue;
            if (pm.checkPermission(Manifest.permission.INTERNET, ai.packageName) != PackageManager.PERMISSION_GRANTED) continue;
            boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
            JSONObject o = new JSONObject();
            o.put("pkg", ai.packageName);
            o.put("name", String.valueOf(pm.getApplicationLabel(ai)));
            o.put("sys", sys);
            out.add(o);
        }
        Collections.sort(out, (a, b) -> a.optString("name").compareToIgnoreCase(b.optString("name")));
        JSONArray a = new JSONArray();
        for (JSONObject o : out) a.put(o);
        return a;
    }

    /* ======================= dispatcher ======================= */
    JSONObject data() throws Exception {
        JSONObject o = new JSONObject();
        synchronized (this) {
            JSONArray ps = new JSONArray();
            for (JSONObject p : profiles) {
                JSONObject x = new JSONObject(p.toString());
                x.remove("cfg");
                ps.put(x);
            }
            o.put("profiles", ps);
            JSONArray ss = new JSONArray();
            for (JSONObject s : subs) ss.put(s);
            o.put("subs", ss);
            o.put("settings", settings);
        }
        o.put("sel", sel());
        o.put("state", stateJson());
        return o;
    }

    Object call(String m, JSONObject a) throws Exception {
        switch (m) {
            case "data": return data();
            case "importText": return importText(a.optString("text"));
            case "addSub": return addSub(a.getString("url"), a.optString("name"), a.optString("ua"));
            case "updateSub": return updateSub(a.getString("id"));
            case "updateAll": {
                int ok = 0; JSONArray errs = new JSONArray();
                List<String> ids = new ArrayList<>();
                synchronized (this) { for (JSONObject s : subs) ids.add(s.optString("id")); }
                for (String id : ids) { try { updateSub(id); ok++; } catch (Exception e) { errs.put(e.getMessage()); } }
                return new JSONObject().put("ok", ok).put("errors", errs);
            }
            case "editSub": {
                synchronized (this) {
                    JSONObject s = sub(a.getString("id"));
                    if (s == null) throw new Exception("подписка не найдена");
                    if (a.has("name")) { s.put("name", a.optString("name")); s.put("autoName", false); }
                    for (String k : new String[]{"url", "ua"}) if (a.has(k)) s.put(k, a.optString(k));
                    if (a.has("auto")) s.put("auto", a.optBoolean("auto"));
                    if (a.has("interval")) s.put("interval", Math.max(1, a.optInt("interval")));
                    saveSubs();
                }
                return true;
            }
            case "delSub": {
                String id = a.getString("id");
                synchronized (this) {
                    subs.removeIf(s -> s.optString("id").equals(id));
                    profiles.removeIf(p -> p.optString("sub").equals(id));
                    saveSubs(); saveProfiles();
                }
                String cur = sel();
                if (cur.equals("auto:" + id) || (!cur.startsWith("auto:") && profile(cur) == null)) prefs.edit().remove("sel").apply();
                return true;
            }
            case "moveSub": {
                synchronized (this) {
                    JSONObject s = sub(a.getString("id"));
                    int i = subs.indexOf(s), j = Math.max(0, Math.min(subs.size() - 1, i + a.optInt("dir")));
                    if (s != null && i != j) { subs.remove(i); subs.add(j, s); saveSubs(); }
                }
                return true;
            }
            case "saveProfile": {
                JSONObject p = a.getJSONObject("p");
                if (!"custom".equals(p.optString("proto"))) XrayConfig.outbound(p, "proxy", settings, null);
                synchronized (this) {
                    String id = p.optString("id");
                    JSONObject old = id.isEmpty() ? null : profile(id);
                    p.remove("link");
                    try { p.put("link", Links.toLink(p)); } catch (Exception ignored) { }
                    if (old != null) {
                        if (old.has("cfg") && !p.has("cfg")) p.put("cfg", old.optString("cfg"));
                        profiles.set(profiles.indexOf(old), p);
                    } else { p.put("id", newId()); p.put("sub", ""); profiles.add(p); }
                    saveProfiles();
                    return p.optString("id");
                }
            }
            case "delProfiles": {
                JSONArray ids = a.getJSONArray("ids");
                java.util.Set<String> set = new java.util.HashSet<>();
                for (int i = 0; i < ids.length(); i++) set.add(ids.getString(i));
                synchronized (this) { profiles.removeIf(p -> set.contains(p.optString("id"))); saveProfiles(); }
                if (set.contains(sel())) prefs.edit().remove("sel").apply();
                return true;
            }
            case "profile": {
                JSONObject p = profile(a.getString("id"));
                if (p == null) throw new Exception("сервер не найден");
                return p;
            }
            case "select": prefs.edit().putString("sel", a.getString("sel")).apply(); return true;
            case "ping": {
                JSONArray ids = a.optJSONArray("ids");
                List<String> l = new ArrayList<>();
                if (ids != null) for (int i = 0; i < ids.length(); i++) l.add(ids.getString(i));
                ping(l, a.optString("mode", settings.optString("pingMode", "real")));
                return l.size();
            }
            case "stopPing": pingGen.incrementAndGet(); return true;
            case "link": {
                JSONObject p = profile(a.getString("id"));
                if (p == null) throw new Exception("сервер не найден");
                if ("custom".equals(p.optString("proto"))) return new JSONObject(p.optString("cfg")).toString(2);
                return p.optString("link").isEmpty() ? Links.toLink(p) : p.optString("link");
            }
            case "exportAll": {
                StringBuilder sb = new StringBuilder();
                synchronized (this) {
                    for (JSONObject s : subs) sb.append(s.optString("url")).append('\n');
                    for (JSONObject p : profiles) if (p.optString("sub").isEmpty() && !"custom".equals(p.optString("proto"))) { try { sb.append(p.optString("link").isEmpty() ? Links.toLink(p) : p.optString("link")).append('\n'); } catch (Exception ignored) { } }
                }
                return sb.toString().trim();
            }
            case "settings": {
                JSONObject patch = a.getJSONObject("patch");
                synchronized (this) {
                    java.util.Iterator<String> it = patch.keys();
                    while (it.hasNext()) { String k = it.next(); settings.put(k, patch.get(k)); }
                    saveSettings();
                }
                return settings;
            }
            case "ip": return ipInfo();
            case "apps": return apps();
            case "logs": { JSONArray l = new JSONArray(); synchronized (logs) { for (String s : logs) l.put(s); } return l; }
            case "config": return new JSONObject(runConfig(false, a.optString("sel")).getString("cfg")).toString(2);
            case "version": return coreVersion();
            default: throw new Exception("неизвестная команда " + m);
        }
    }
}
