package app.neonvpn;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Quick Settings tile: one tap to connect / disconnect from the notification shade. */
public class QsTile extends TileService {

    static void refresh(Context c) {
        try { TileService.requestListeningState(c, new ComponentName(c, QsTile.class)); } catch (Exception ignored) { }
    }

    @Override
    public void onStartListening() { update(); }

    void update() {
        Tile t = getQsTile();
        if (t == null) return;
        VpnCore core = VpnCore.get(this);
        boolean on = "on".equals(core.state) || "connecting".equals(core.state);
        t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.setLabel("Neon VPN");
        if (Build.VERSION.SDK_INT >= 29) t.setSubtitle("connecting".equals(core.state) ? "Подключение…" : on ? core.activeName : "Выключен");
        t.updateTile();
    }

    @Override
    public void onClick() {
        VpnCore core = VpnCore.get(this);
        if ("on".equals(core.state) || "connecting".equals(core.state)) { NeonVpnService.stop(this); update(); return; }
        if (VpnService.prepare(this) != null) {
            Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("connect", true);
            if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 7, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            else startActivityAndCollapse(i);
            return;
        }
        NeonVpnService.start(this);
        update();
    }
}
