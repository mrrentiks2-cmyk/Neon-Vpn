Сюда при сборке на GitHub скачивается ядро Xray: libv2ray.aar (AndroidLibXrayLite, LGPL-3.0).
Для сборки на компьютере скачайте его вручную:
https://github.com/2dust/AndroidLibXrayLite/releases/download/v26.9.30/libv2ray.aar
